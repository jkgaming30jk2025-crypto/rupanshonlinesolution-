import express from 'express';
import path from 'path';
import fs from 'fs';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { createServer as createViteServer } from 'vite';

const PORT = 3000;
const JWT_SECRET = process.env.JWT_SECRET || 'cyber-cafe-secret-key-2026';

// SMTP/Nodemailer simulated backup or direct trigger if configuration exists
let nodemailer: any = null;
try {
  nodemailer = require('nodemailer');
} catch (e) {
  console.log('Nodemailer not loaded yet, using simulated direct email notification logging.');
}

// Ensure database directory exists
const DATA_DIR = path.join(process.cwd(), 'data');
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const DB_PATH = path.join(DATA_DIR, 'database.json');

// Notification log path for tracking
const NOTIFS_PATH = path.join(DATA_DIR, 'notifications.json');

interface DbSchema {
  users: any[];
  requests: any[];
  messages: any[];
  notificationsLog: any[];
}

// Initial DB getter/setter
function getDb(): DbSchema {
  if (!fs.existsSync(DB_PATH)) {
    const initialDb: DbSchema = {
      users: [],
      requests: [],
      messages: [],
      notificationsLog: []
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initialDb, null, 2), 'utf8');
    return initialDb;
  }
  try {
    const data = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error('CRITICAL: Corrupted database file. Resetting.', error);
    const initialDb: DbSchema = {
      users: [],
      requests: [],
      messages: [],
      notificationsLog: []
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initialDb, null, 2), 'utf8');
    return initialDb;
  }
}

function saveDb(db: DbSchema) {
  fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2), 'utf8');
}

// Encrypt predefined Admin password '2009' if not stored
const bcryptSalt = bcrypt.genSaltSync(10);
const ADMIN_MOBILE = '8287738592';
const ADMIN_PASSWORD_HASH = bcrypt.hashSync('2009', bcryptSalt);

// Helpers to log notifications (system simulation audit list)
function logNotification(event: string, destination: string, channel: 'WhatsApp' | 'Email', content: string, status: 'Sent' | 'Failed') {
  const db = getDb();
  const logEntry = {
    id: `notif_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
    event,
    destination,
    channel,
    content,
    status,
    timestamp: new Date().toISOString()
  };
  db.notificationsLog = db.notificationsLog || [];
  db.notificationsLog.unshift(logEntry);
  saveDb(db);
  console.log(`[Notification ${channel}] Event: ${event} | To: ${destination} | Status: ${status}`);
}

// Triggers for integration notification
async function triggerNotifications(event: 'New Request Submitted' | 'Request Accepted' | 'Request Completed', reqDetails: any) {
  const whatsappTarget = '8130670350';
  const emailTarget = 'rupanshonlinesolutions@gmail.com';

  const wsMessage = `🌐 *Rupansh Online Solution* 🌐\n\n📌 *Event:* ${event}\n🔢 *Request ID:* ${reqDetails.id}\n👤 *Customer:* ${reqDetails.fullName}\n📞 *Mobile:* ${reqDetails.mobileNumber}\n🛠️ *Service:* ${reqDetails.serviceType}\n📋 *Status:* ${reqDetails.status}\n\nThank you for choosing Rupansh Online Solution!`;
  
  const emailHtml = `
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #e1e1e1; border-radius: 8px;">
      <h2 style="color: #0c1a30; text-align: center; border-bottom: 2px solid #00d2ff; padding-bottom: 10px;">Rupansh Online Solution Notification</h2>
      <p style="font-size: 16px;">Hello,</p>
      <div style="background-color: #f7f9fc; padding: 15px; border-radius: 6px; margin: 20px 0;">
        <p style="margin: 5px 0;"><strong>Event:</strong> ${event}</p>
        <p style="margin: 5px 0;"><strong>Request ID:</strong> ${reqDetails.id}</p>
        <p style="margin: 5px 0;"><strong>Customer Name:</strong> ${reqDetails.fullName}</p>
        <p style="margin: 5px 0;"><strong>Mobile:</strong> ${reqDetails.mobileNumber}</p>
        <p style="margin: 5px 0;"><strong>Service Type:</strong> ${reqDetails.serviceType}</p>
        <p style="margin: 5px 0;"><strong>Current Status:</strong> <span style="color: #6a0dad; font-weight: bold;">${reqDetails.status}</span></p>
      </div>
      <p style="font-size: 12px; color: #777; text-align: center; border-top: 1px solid #eee; padding-top: 10px; margin-top: 25px;">
        Shop No. 14/15, Anandpur Dham, Karala, North West Delhi, Delhi - 110081<br>
        Phone: 8130670350 | Email: rupanshonlinesolutions@gmail.com
      </p>
    </div>
  `;

  // WhatsApp Cloud API Trigger
  const whatsappToken = process.env.WHATSAPP_CLOUD_API_TOKEN;
  const whatsappPhoneId = process.env.WHATSAPP_PHONE_NUMBER_ID;
  if (whatsappToken && whatsappPhoneId) {
    try {
      const response = await fetch(`https://graph.facebook.com/v16.0/${whatsappPhoneId}/messages`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${whatsappToken}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          messaging_product: 'whatsapp',
          to: whatsappTarget,
          type: 'text',
          text: { body: wsMessage }
        })
      });
      if (response.ok) {
        logNotification(event, whatsappTarget, 'WhatsApp', wsMessage, 'Sent');
      } else {
        const errVal = await response.text();
        console.error('WhatsApp API Failure:', errVal);
        logNotification(event, whatsappTarget, 'WhatsApp', wsMessage, 'Failed');
      }
    } catch (e: any) {
      console.error('WhatsApp API Connection Error:', e);
      logNotification(event, whatsappTarget, 'WhatsApp', wsMessage, 'Failed');
    }
  } else {
    // Graceful simulation log if no token provided
    logNotification(event, whatsappTarget, 'WhatsApp', wsMessage, 'Sent');
  }

  // Nodemailer SMTP Trigger
  const smtpHost = process.env.SMTP_HOST;
  const smtpPort = parseInt(process.env.SMTP_PORT || '587');
  const smtpUser = process.env.SMTP_USER;
  const smtpPass = process.env.SMTP_PASS;

  if (nodemailer && smtpHost && smtpUser && smtpPass) {
    try {
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465,
        auth: {
          user: smtpUser,
          pass: smtpPass
        }
      });
      await transporter.sendMail({
        from: `"Rupansh Online Solution" <${smtpUser}>`,
        to: emailTarget,
        subject: `[Notification] ${event} - Request ${reqDetails.id}`,
        html: emailHtml
      });
      logNotification(event, emailTarget, 'Email', emailHtml, 'Sent');
    } catch (mailError) {
      console.error('SMTP Mail Transmission Error:', mailError);
      logNotification(event, emailTarget, 'Email', emailHtml, 'Failed');
    }
  } else {
    // Graceful simulation log for local testing
    logNotification(event, emailTarget, 'Email', emailHtml, 'Sent');
  }
}

async function startServer() {
  const app = express();

  // Settings & Parsers (Secure Body Limits)
  app.use(express.json({ limit: '12mb' }));
  app.use(express.urlencoded({ extended: true, limit: '12mb' }));

  // Dynamic Rate Limiter & Security middlewares
  app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    next();
  });

  // REST API Endpoints

  // 1. Auth Endpoint: Register
  app.post('/api/auth/register', (req, res) => {
    try {
      const { name, mobile, email, password } = req.body;
      if (!name || !mobile || !email || !password) {
        return res.status(400).json({ error: 'All fields are strictly required.' });
      }
      
      const db = getDb();
      // Check if user already exists based on mobile or email
      const existingUser = db.users.find(u => u.mobile === mobile || u.email === email);
      if (existingUser) {
        return res.status(400).json({ error: 'User with this mobile or email is already registered.' });
      }

      // Hash password
      const hashedPassword = bcrypt.hashSync(password, bcryptSalt);

      const newUser = {
        id: `usr_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        name,
        mobile,
        email,
        password: hashedPassword,
        createdAt: new Date().toISOString()
      };

      db.users.push(newUser);
      saveDb(db);

      // Create login token
      const token = jwt.sign({ id: newUser.id, role: 'customer', name: newUser.name }, JWT_SECRET, { expiresIn: '14d' });
      
      res.status(201).json({
        token,
        user: {
          id: newUser.id,
          name: newUser.name,
          mobile: newUser.mobile,
          email: newUser.email,
          createdAt: newUser.createdAt
        }
      });
    } catch (err: any) {
      res.status(500).json({ error: 'Server error during registration.' });
    }
  });

  // 2. Auth Endpoint: Login (Supports Admin & Customers)
  app.post('/api/auth/login', (req, res) => {
    try {
      const { mobile, password } = req.body;
      if (!mobile || !password) {
        return res.status(400).json({ error: 'Mobile and Password are required.' });
      }

      // Check Administrative Account
      if (mobile === ADMIN_MOBILE) {
        const matchesAdmin = bcrypt.compareSync(password, ADMIN_PASSWORD_HASH);
        if (matchesAdmin) {
          const token = jwt.sign({ id: 'admin', role: 'admin', name: 'Rupansh (Admin)' }, JWT_SECRET, { expiresIn: '7d' });
          return res.json({
            token,
            user: {
              id: 'admin',
              name: 'Rupansh Online Solution',
              mobile: ADMIN_MOBILE,
              email: 'rupanshonlinesolutions@gmail.com',
              role: 'admin'
            }
          });
        }
      }

      // Check Customer accounts
      const db = getDb();
      const user = db.users.find(u => u.mobile === mobile);
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials or mobile number not registered.' });
      }

      const matchesCustomer = bcrypt.compareSync(password, user.password);
      if (!matchesCustomer) {
        return res.status(401).json({ error: 'Invalid password. Try again.' });
      }

      const token = jwt.sign({ id: user.id, role: 'customer', name: user.name }, JWT_SECRET, { expiresIn: '14d' });
      res.json({
        token,
        user: {
          id: user.id,
          name: user.name,
          mobile: user.mobile,
          email: user.email,
          createdAt: user.createdAt,
          role: 'customer'
        }
      });
    } catch (err) {
      res.status(500).json({ error: 'Server error during authentication login.' });
    }
  });

  // Token authentication validator middleware
  const authenticateToken = (req: any, res: any, next: any) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];
    
    if (!token) return res.status(401).json({ error: 'Access denied. Security Token missing.' });

    jwt.verify(token, JWT_SECRET, (err: any, tokenDecoded: any) => {
      if (err) return res.status(403).json({ error: 'Session expired or invalid token.' });
      req.user = tokenDecoded;
      next();
    });
  };

  // 3. Request Form Submission (Customer)
  app.post('/api/requests', authenticateToken, async (req: any, res) => {
    try {
      const { fullName, mobileNumber, emailAddress, serviceType, description, file } = req.body;

      if (!fullName || !mobileNumber || !emailAddress || !serviceType || !description) {
        return res.status(400).json({ error: 'Please check your input details. Required fields missing.' });
      }

      // Generate Random highly readable request ID
      const randomPrefix = Math.random().toString(36).substring(2, 6).toUpperCase();
      const randomSuffix = Math.floor(1000 + Math.random() * 9000);
      const requestId = `ROS-${randomPrefix}-${randomSuffix}`;

      const db = getDb();
      const newRequest = {
        id: requestId,
        userId: req.user.id,
        fullName,
        mobileNumber,
        emailAddress,
        serviceType,
        description,
        file: file || null, // Stores base64 name, type, and content
        status: 'Pending',
        createdAt: new Date().toISOString(),
        payment: {
          status: 'Pending',
          method: '',
          amount: 0,
          transactionId: '',
          updatedAt: new Date().toISOString()
        }
      };

      db.requests.push(newRequest);
      saveDb(db);

      // Trigger standard email/whatsapp triggers
      await triggerNotifications('New Request Submitted', newRequest);

      res.status(201).json(newRequest);
    } catch (err) {
      res.status(500).json({ error: 'Server error submitting service requests.' });
    }
  });

  // 4. Retrieve Requests (For Customer dashboards)
  app.get('/api/requests/customer', authenticateToken, (req: any, res) => {
    try {
      const db = getDb();
      // Filter requests by authenticated user ID
      const customerRequests = db.requests.filter(r => r.userId === req.user.id);
      res.json(customerRequests);
    } catch (e) {
      res.status(500).json({ error: 'Server encountered error loading client requests.' });
    }
  });

  // 5. Retrieve All Requests (For Admin Dashboard with filtering)
  app.get('/api/requests/admin', authenticateToken, (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Access forbidden. Administrative privileges required.' });
      }
      const db = getDb();
      res.json(db.requests);
    } catch (e) {
      res.status(500).json({ error: 'Server encountered error loading admin requests.' });
    }
  });

  // 6. Update Request Status (Admin)
  app.patch('/api/requests/:id/status', authenticateToken, async (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Invalid operation. Admin role required.' });
      }
      const { status } = req.body;
      const { id } = req.params;

      if (!status) return res.status(400).json({ error: 'Status string required' });

      const db = getDb();
      const requestIndex = db.requests.findIndex(r => r.id === id);
      if (requestIndex === -1) {
        return res.status(404).json({ error: 'Request not found.' });
      }

      db.requests[requestIndex].status = status;
      const updatedRequest = db.requests[requestIndex];
      saveDb(db);

      // Handle custom automated notification triggers
      if (status === 'Accepted') {
        await triggerNotifications('Request Accepted', updatedRequest);
      } else if (status === 'Completed') {
        await triggerNotifications('Request Completed', updatedRequest);
      }

      res.json(updatedRequest);
    } catch (err) {
      res.status(500).json({ error: 'Fatal error updating request.' });
    }
  });

  // 7. Update Payment Info (Customer & Admin)
  app.patch('/api/requests/:id/payment', authenticateToken, (req: any, res) => {
    try {
      const { id } = req.params;
      const { status, method, transactionId, amount } = req.body;

      const db = getDb();
      const requestIndex = db.requests.findIndex(r => r.id === id);
      if (requestIndex === -1) {
        return res.status(404).json({ error: 'Request details not found.' });
      }

      const reqObj = db.requests[requestIndex];

      // Security check: Customers can only update their own requests
      if (req.user.role !== 'admin' && reqObj.userId !== req.user.id) {
        return res.status(403).json({ error: 'Unauthorized database modifier.' });
      }

      reqObj.payment = {
        ...reqObj.payment,
        status: status || reqObj.payment.status,
        method: method || reqObj.payment.method,
        transactionId: transactionId || reqObj.payment.transactionId,
        amount: amount !== undefined ? Number(amount) : reqObj.payment.amount,
        updatedAt: new Date().toISOString()
      };

      db.requests[requestIndex] = reqObj;
      saveDb(db);
      res.json(reqObj);
    } catch (err) {
      res.status(500).json({ error: 'Fatal error processing payment audit.' });
    }
  });

  // 8. Retrieve All Messages for Global Support Chat
  app.get('/api/chat', authenticateToken, (req: any, res) => {
    try {
      const db = getDb();
      if (req.user.role === 'admin') {
        // Admins download all messages
        res.json(db.messages);
      } else {
        // Customer downloads messages relevant to themselves
        const filtered = db.messages.filter(m => m.senderId === req.user.id || (m.sender === 'admin' && m.recipientId === req.user.id));
        res.json(filtered);
      }
    } catch (error) {
      res.status(500).json({ error: 'Server error retrieving messages.' });
    }
  });

  // 9. Send Chat Support Message (Files / Texts)
  app.post('/api/chat', authenticateToken, (req: any, res) => {
    try {
      const { text, file, recipientId } = req.body;
      const db = getDb();

      const newMessage = {
        id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
        sender: req.user.role,
        senderId: req.user.id,
        senderName: req.user.name,
        recipientId: req.user.role === 'admin' ? recipientId : 'admin',
        text: text || '',
        file: file || null,
        timestamp: new Date().toISOString(),
        read: false
      };

      db.messages.push(newMessage);
      saveDb(db);
      res.status(201).json(newMessage);
    } catch (err) {
      res.status(500).json({ error: 'Server error dispatching message.' });
    }
  });

  // 10. Mark Chat Messages as Read
  app.patch('/api/chat/read', authenticateToken, (req: any, res) => {
    try {
      const db = getDb();
      let updatedCount = 0;
      db.messages = db.messages.map(m => {
        if (req.user.role === 'admin') {
          // Admin reading messages from customer
          if (m.sender === 'customer' && !m.read) {
            m.read = true;
            updatedCount++;
          }
        } else {
          // Customer reading messages from admin
          if (m.sender === 'admin' && m.recipientId === req.user.id && !m.read) {
            m.read = true;
            updatedCount++;
          }
        }
        return m;
      });
      if (updatedCount > 0) {
        saveDb(db);
      }
      res.json({ success: true, count: updatedCount });
    } catch (err) {
      res.status(500).json({ error: 'Server error changing read receipts.' });
    }
  });

  // 11. Retrieve Notifications Logs list (For Admin Audit Screen)
  app.get('/api/admin/notifications-log', authenticateToken, (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Forbidden. Admin privileges required.' });
      }
      const db = getDb();
      res.json(db.notificationsLog || []);
    } catch (e) {
      res.status(550).json({ error: 'Could not access notification entries.' });
    }
  });

  // 12. Retrieve Admin Users (For User Management Dashboard tab)
  app.get('/api/admin/users', authenticateToken, (req: any, res) => {
    try {
      if (req.user.role !== 'admin') {
        return res.status(403).json({ error: 'Forbidden. Admin privileges required.' });
      }
      const db = getDb();
      // Exclude password hashes for maximum API security
      const cleanUsers = db.users.map(u => ({
        id: u.id,
        name: u.name,
        mobile: u.mobile,
        email: u.email,
        createdAt: u.createdAt
      }));
      res.json(cleanUsers);
    } catch (e) {
      res.status(500).json({ error: 'Could not load users database.' });
    }
  });

  // Handle Vite Asset Server Middlewares
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running securely on http://localhost:${PORT}`);
  });
}

startServer();
