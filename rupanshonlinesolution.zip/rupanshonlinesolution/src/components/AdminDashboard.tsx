import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  Search, 
  Check, 
  X, 
  User, 
  Download, 
  CreditCard, 
  MessageSquare, 
  Layers, 
  ShieldAlert, 
  Send, 
  Users, 
  TrendingUp, 
  Bell, 
  LogOut, 
  Clock, 
  Loader2, 
  CheckCircle2, 
  MapPin, 
  Activity,
  FileCheck2,
  AlertTriangle
} from 'lucide-react';
import { ServiceRequest, ChatMessage, DashboardStats } from '../types';
import ChatSupport from './ChatSupport';

interface AdminDashboardProps {
  token: string | null;
  user: { id: string; name: string; role: string } | null;
  onLogout: () => void;
}

export default function AdminDashboard({ token, user, onLogout }: AdminDashboardProps) {
  const [activeTab, setActiveTab] = useState<'requests' | 'payments' | 'chat' | 'users' | 'notifications'>('requests');
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [filteredRequests, setFilteredRequests] = useState<ServiceRequest[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [selectedRequest, setSelectedRequest] = useState<ServiceRequest | null>(null);

  // Chat select target
  const [activeChatRecipientId, setActiveChatRecipientId] = useState<string | null>(null);
  const [activeChatRecipientName, setActiveChatRecipientName] = useState<string>('');

  // Notifications audit trail logs
  const [notificationsLog, setNotificationsLog] = useState<any[]>([]);

  // Users lists
  const [usersList, setUsersList] = useState<any[]>([]);

  const fetchAdminData = async () => {
    if (!token) return;
    setLoading(true);
    try {
      // 1. Fetch all requests
      const respRequests = await fetch('/api/requests/admin', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (respRequests.ok) {
        const data = await respRequests.json();
        setRequests(data);
        setFilteredRequests(data);
      }

      // 2. Fetch notifications log
      const respNotifs = await fetch('/api/admin/notifications-log', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (respNotifs.ok) {
        const notifLog = await respNotifs.json();
        setNotificationsLog(notifLog);
      }

      // 3. Fetch users directory
      const respUsers = await fetch('/api/admin/users', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (respUsers.ok) {
        const users = await respUsers.json();
        setUsersList(users);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
  }, [token]);

  // Live filtering on query search change
  useEffect(() => {
    const query = searchQuery.toLowerCase().trim();
    let result = requests;

    if (query) {
      result = result.filter(r => 
        r.fullName.toLowerCase().includes(query) ||
        r.mobileNumber.includes(query) ||
        r.id.toLowerCase().includes(query) ||
        r.serviceType.toLowerCase().includes(query)
      );
    }

    if (statusFilter) {
      result = result.filter(r => r.status === statusFilter);
    }

    setFilteredRequests(result);
  }, [searchQuery, statusFilter, requests]);

  // Handle status update change API
  const handleUpdateStatus = async (id: string, newStatus: 'Accepted' | 'Rejected' | 'In Progress' | 'Completed') => {
    if (!token) return;
    try {
      const resp = await fetch(`/api/requests/${id}/status`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: newStatus })
      });

      if (resp.ok) {
        const updated = await resp.json();
        // Update local arrays state
        const updatedArr = requests.map(r => r.id === id ? updated : r);
        setRequests(updatedArr);
        if (selectedRequest?.id === id) {
          setSelectedRequest(updated);
        }
        
        // Refresh notifications log
        const respNotifs = await fetch('/api/admin/notifications-log', {
          headers: { 'Authorization': `Bearer ${token}` }
        });
        if (respNotifs.ok) {
          const notifLog = await respNotifs.json();
          setNotificationsLog(notifLog);
        }
      } else {
        alert('Could not update application status.');
      }
    } catch (e) {
      alert('Communication error with government routing simulation.');
    }
  };

  // Handle payment processing receipts
  const handleUpdatePaymentStatus = async (id: string, payStatus: 'Paid' | 'Failed') => {
    if (!token) return;
    try {
      const resp = await fetch(`/api/requests/${id}/payment`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ status: payStatus })
      });

      if (resp.ok) {
        const updated = await resp.json();
        const updatedArr = requests.map(r => r.id === id ? updated : r);
        setRequests(updatedArr);
        if (selectedRequest?.id === id) {
          setSelectedRequest(updated);
        }
      } else {
        alert('Could not record payment.');
      }
    } catch (e) {
      alert('Failed to update payment. Please try again.');
    }
  };

  // Live calculations for Admin dashboard indicators
  const totalCount = requests.length;
  const pendingCount = requests.filter(r => r.status === 'Pending').length;
  const acceptedCount = requests.filter(r => r.status === 'Accepted').length;
  const completedCount = requests.filter(r => r.status === 'Completed').length;
  const inProgressCount = requests.filter(r => r.status === 'In Progress').length;
  
  // Total Revenue Sums
  const totalRevenue = requests
    .filter(r => r.payment.status === 'Paid')
    .reduce((sum, r) => sum + (r.payment.amount || 150), 0);

  // Today's Requests simulation
  const todayRequests = requests.filter(r => {
    const today = new Date().toDateString();
    return new Date(r.createdAt).toDateString() === today;
  }).length;

  return (
    <div id="admin_dashboard" className="min-h-screen bg-slate-950/95 text-slate-100 font-sans">
      
      {/* Background neon visual glows */}
      <div className="absolute top-20 right-1/4 w-96 h-96 bg-emerald-700/5 rounded-full blur-[120px] pointer-events-none animate-pulse-slow"></div>
      <div className="absolute bottom-20 left-1/4 w-96 h-96 bg-emerald-750/5 rounded-full blur-[120px] pointer-events-none animate-pulse-slow"></div>

      {/* Persistent admin header bar */}
      <div className="bg-slate-900 border-b border-slate-800 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600 flex items-center justify-center text-white font-extrabold text-xl shadow-lg">
              🛡️
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold font-display tracking-tight text-white flex items-center gap-2">
                Operator Panel <span className="bg-rose-500/20 text-rose-400 text-[10px] font-mono font-black uppercase px-2 py-0.5 rounded-full border border-rose-500/10">ROOT</span>
              </h1>
              <p className="text-xs text-slate-400 font-mono">
                Logged in: <span className="text-emerald-400 font-bold">Rupansh (Admin)</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={fetchAdminData}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs py-2.5 px-4 font-semibold rounded-xl transition-all h-10 border border-slate-700 cursor-pointer"
            >
              🔄 Sync DB System
            </button>
            <button
              onClick={onLogout}
              className="bg-red-500/20 hover:bg-red-500 border border-red-500/30 font-bold text-xs py-2.5 px-4 rounded-xl text-red-400 hover:text-white transition-all h-10 cursor-pointer"
            >
              Sign Out Securely
            </button>
          </div>

        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Dynamic Analytics Counters Widget Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-7 gap-4 mb-8">
          
          <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl text-left shadow-sm shadow-emerald-500/5">
            <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Total Tickets</p>
            <p className="text-2xl md:text-3xl font-black font-display text-white mt-1">{totalCount}</p>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl text-left shadow-sm shadow-emerald-500/5">
            <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Pending</p>
            <p className="text-2xl md:text-3xl font-black font-display text-orange-400 mt-1">{pendingCount}</p>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl text-left shadow-sm shadow-emerald-500/5">
            <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Accepted</p>
            <p className="text-2xl md:text-3xl font-black font-display text-emerald-405 mt-1 text-emerald-400">{acceptedCount}</p>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl text-left shadow-sm shadow-emerald-500/5 font-sans">
            <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">In Progress</p>
            <p className="text-2xl md:text-3xl font-black font-display text-orange-500 mt-1">{inProgressCount}</p>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl text-left shadow-sm shadow-emerald-500/5">
            <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Completed</p>
            <p className="text-2xl md:text-3xl font-black font-display text-emerald-550 mt-1 text-emerald-500">{completedCount}</p>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl text-left shadow-sm shadow-emerald-500/5">
            <p className="text-[10px] uppercase font-mono tracking-wider text-slate-400">Today&apos;s Forms</p>
            <p className="text-2xl md:text-3xl font-black font-display text-orange-400 mt-1">{todayRequests}</p>
          </div>

          <div className="bg-slate-900/50 border border-slate-800 p-4 rounded-2xl col-span-2 lg:col-span-1 text-left bg-gradient-to-tr from-emerald-950/40 to-slate-900/50">
            <p className="text-[10px] uppercase font-mono tracking-wider text-emerald-400 font-bold">Paid Revenue</p>
            <p className="text-2xl md:text-3xl font-black font-display text-emerald-400 mt-1">₹{totalRevenue}</p>
          </div>

        </div>

        {/* Dashboard Sections Toggle Navigation Bar */}
        <div className="flex border-b border-slate-800 mb-8 overflow-x-auto gap-2 md:gap-4 pb-2">
          
          <button
            onClick={() => setActiveTab('requests')}
            className={`cursor-pointer px-4 py-3 text-sm font-semibold whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'requests' 
                ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' 
                : 'text-slate-400 hover:text-orange-400 hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            <Layers className="w-4 h-4" /> Operations ({requests.length})
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`cursor-pointer px-4 py-3 text-sm font-semibold whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'payments' 
                ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' 
                : 'text-slate-400 hover:text-orange-400 hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            <CreditCard className="w-4 h-4" /> Payments ledger
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`cursor-pointer px-4 py-3 text-sm font-semibold whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'chat' 
                ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' 
                : 'text-slate-400 hover:text-orange-400 hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            <MessageSquare className="w-4 h-4" /> Live Help Desk Support
          </button>

          <button
            onClick={() => setActiveTab('users')}
            className={`cursor-pointer px-4 py-3 text-sm font-semibold whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'users' 
                ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' 
                : 'text-slate-400 hover:text-orange-400 hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            <Users className="w-4 h-4" /> Registered Users ({usersList.length})
          </button>

          <button
            onClick={() => setActiveTab('notifications')}
            className={`cursor-pointer px-4 py-3 text-sm font-semibold whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'notifications' 
                ? 'bg-orange-500/10 text-orange-400 border border-orange-500/20' 
                : 'text-slate-400 hover:text-orange-400 hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            <Bell className="w-4 h-4" /> Messaging Logs ({notificationsLog.length})
          </button>

        </div>

        {/* TAB 1: OPERATIONAL REQUESTS MANAGER */}
        {activeTab === 'requests' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 text-left">
            
            {/* Left side requests tracker with filters */}
            <div className="lg:col-span-2 space-y-4">
              
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <span className="absolute inset-y-0 left-3 flex items-center pointer-events-none text-slate-500">
                    <Search className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search candidate legal names, files, mobile, id..."
                    className="w-full bg-slate-900 border border-slate-850 rounded-xl text-xs sm:text-sm pl-10 pr-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 text-white font-sans"
                  />
                </div>

                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="bg-slate-900 border border-slate-850 text-xs sm:text-sm text-slate-300 rounded-xl px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 font-sans"
                >
                  <option value="">All Statuses</option>
                  <option value="Pending">Pending</option>
                  <option value="Accepted">Accepted</option>
                  <option value="In Progress">In Progress</option>
                  <option value="Rejected">Rejected</option>
                  <option value="Completed">Completed</option>
                </select>
              </div>

              {loading ? (
                <div className="flex justify-center items-center py-12">
                  <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
                </div>
              ) : filteredRequests.length === 0 ? (
                <div className="text-center py-12 border border-dashed border-slate-800 rounded-2xl bg-slate-900/20">
                  <FileText className="w-12 h-12 text-slate-600 mx-auto mb-3" />
                  <p className="font-semibold text-slate-400">No applications match your filtering criteria.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredRequests.map(req => {
                    const isSelected = selectedRequest?.id === req.id;
                    return (
                      <div
                        key={req.id}
                        onClick={() => setSelectedRequest(req)}
                        className={`p-5 rounded-2xl bg-slate-900/50 border text-left cursor-pointer transition-all ${
                          isSelected 
                            ? 'ring-2 ring-orange-500 border-orange-500 bg-orange-500/5' 
                            : 'border-slate-800 hover:bg-slate-900'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 font-sans">
                          <div>
                            <div className="flex items-center gap-2">
                              <span className="text-[10px] font-mono font-bold bg-slate-800 text-orange-400 px-2 py-0.5 rounded">
                                {req.id}
                              </span>
                              <span className="text-[10px] text-slate-500 font-mono">
                                {new Date(req.createdAt).toLocaleDateString()}
                              </span>
                            </div>
                            <h4 className="font-bold text-white mt-1.5 font-display text-base">
                              {req.fullName}
                            </h4>
                            <p className="text-xs text-slate-400 font-medium mt-0.5">
                              {req.serviceType}
                            </p>
                          </div>

                          <div className="flex items-center gap-3 self-stretch sm:self-auto justify-between sm:justify-end">
                            <span className={`text-[11px] font-black px-2.5 py-0.5 rounded-full ${
                              req.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-400' :
                              req.status === 'In Progress' ? 'bg-orange-500/10 text-orange-400' :
                              req.status === 'Accepted' ? 'bg-emerald-500/10 text-emerald-400' :
                              req.status === 'Rejected' ? 'bg-rose-500/10 text-rose-400' :
                              'bg-amber-500/10 text-amber-400'
                            }`}>
                              ● {req.status}
                            </span>
                            
                            <span className={`text-[10px] font-mono font-extrabold px-2 py-0.5 rounded ${
                              req.payment.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'
                            }`}>
                              {req.payment.status}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}

            </div>

            {/* Right details controller panel */}
            <div className="space-y-4">
              <h3 className="text-lg font-bold font-display text-white flex items-center gap-2">
                📋 Administration controller
              </h3>

              {selectedRequest ? (
                <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl shadow-md border-emerald-500/10 space-y-6 animate-fade-in">
                  
                  <div>
                    <span className="text-[10px] font-mono text-slate-400">Selected Candidate profile</span>
                    <h4 className="text-lg font-extrabold text-white font-display mt-0.5">{selectedRequest.fullName}</h4>
                    <p className="text-xs text-orange-400 font-mono mt-0.5">Ticket ID: {selectedRequest.id}</p>
                  </div>

                  <div className="space-y-3.5 text-xs bg-slate-950 p-4 rounded-xl border border-slate-850">
                    <p className="text-slate-300"><strong>Mobile:</strong> <a href={`tel:${selectedRequest.mobileNumber}`} className="text-orange-400 hover:underline">{selectedRequest.mobileNumber}</a></p>
                    <p className="text-slate-300"><strong>Email:</strong> <span className="font-mono">{selectedRequest.emailAddress}</span></p>
                    <p className="text-slate-300"><strong>Category:</strong> {selectedRequest.serviceType}</p>
                    <p className="text-slate-300"><strong>Description:</strong> {selectedRequest.description}</p>
                  </div>

                  {/* Render attached scan/paper proof natively directly in the browser */}
                  {selectedRequest.file ? (
                    <div className="p-3 bg-slate-950 border border-slate-850 rounded-xl flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2 min-w-0 font-sans">
                        <FileText className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                        <div className="min-w-0 text-left">
                          <p className="font-semibold text-slate-300 truncate max-w-[130px]">{selectedRequest.file.name}</p>
                          <p className="text-[10px] text-slate-500 font-mono">{(selectedRequest.file.size / 1024).toFixed(1)} KB</p>
                        </div>
                      </div>
                      
                      {/* Base64 download trigger */}
                      <a 
                        href={selectedRequest.file.content}
                        download={selectedRequest.file.name}
                        className="bg-orange-500/20 hover:bg-orange-500/40 text-orange-400 text-xs px-2.5 py-1 rounded font-mono font-bold transition-all h-7 flex items-center"
                      >
                        💾 Download
                      </a>
                    </div>
                  ) : (
                    <p className="text-[11px] text-slate-500 bg-slate-950 p-3 rounded-xl border border-dashed border-slate-850">
                      ⚠️ No document uploaded for this request.
                    </p>
                  )}

                  {/* Operational administrative controls */}
                  <div className="pt-4 border-t border-slate-800 space-y-2">
                    <p className="text-[11px] text-slate-400 uppercase font-mono tracking-wider font-bold mb-2 text-left">Set Status Action:</p>
                    
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleUpdateStatus(selectedRequest.id, 'Accepted')}
                        disabled={selectedRequest.status === 'Accepted'}
                        className="bg-emerald-550/20 hover:bg-emerald-600 text-emerald-300 hover:text-white border border-emerald-500/35 text-xs font-bold py-2 px-3 rounded-lg transition-all cursor-pointer disabled:opacity-40"
                      >
                        ✓ Accept Request
                      </button>
                      <button
                        onClick={() => handleUpdateStatus(selectedRequest.id, 'In Progress')}
                        disabled={selectedRequest.status === 'In Progress'}
                        className="bg-orange-500/20 hover:bg-orange-500 text-orange-300 hover:text-white border border-orange-500/35 text-xs font-bold py-2 px-3 rounded-lg transition-all cursor-pointer disabled:opacity-40 font-sans"
                      >
                        ⚡ Mark In Progress
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-2">
                      <button
                        onClick={() => handleUpdateStatus(selectedRequest.id, 'Completed')}
                        disabled={selectedRequest.status === 'Completed'}
                        className="col-span-1 bg-emerald-500/20 hover:bg-emerald-500 text-emerald-300 hover:text-white border border-emerald-500/30 text-xs font-bold py-2 px-3 rounded-lg transition-all cursor-pointer disabled:opacity-40"
                      >
                        ❇️ Complete Ticket
                      </button>
                      <button
                        onClick={() => handleUpdateStatus(selectedRequest.id, 'Rejected')}
                        disabled={selectedRequest.status === 'Rejected'}
                        className="col-span-1 bg-rose-500/20 hover:bg-rose-500 text-rose-300 hover:text-white border border-rose-500/30 text-xs font-bold py-2 px-3 rounded-lg transition-all cursor-pointer disabled:opacity-40"
                      >
                        ✗ Reject Case
                      </button>
                    </div>

                    <div className="pt-3">
                      <button
                        onClick={() => {
                          setActiveChatRecipientId(selectedRequest.userId);
                          setActiveChatRecipientName(selectedRequest.fullName);
                          setActiveTab('chat');
                        }}
                        className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white text-xs font-extrabold py-2.5 rounded-xl transition shadow flex items-center justify-center gap-1.5 cursor-pointer font-sans"
                      >
                        💬 Start Chatting with {selectedRequest.fullName.split(' ')[0]}
                      </button>
                    </div>

                  </div>

                </div>
              ) : (
                <div className="bg-slate-900 border border-slate-800 p-8 rounded-2xl text-center py-12">
                  <Activity className="w-12 h-12 text-slate-700 mx-auto mb-2 animate-pulse" />
                  <p className="text-xs text-slate-500 font-medium">Select any applicant profile from the left tab list to operate status overrides & chat integrations.</p>
                </div>
              )}
            </div>

          </div>
        )}

        {/* TAB 2: PAYMENTS STATS & AUDITS */}
        {activeTab === 'payments' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-left space-y-4">
            <h3 className="text-lg font-bold font-display text-white flex items-center gap-2">
              💳 Payment ledger checks
            </h3>
            
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left text-slate-300">
                <thead className="text-[10px] text-slate-500 uppercase bg-slate-950 font-mono tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="py-3.5 px-4 font-bold">Ticket ID</th>
                    <th className="py-3.5 px-4 font-bold">Applicant</th>
                    <th className="py-3.5 px-4 font-bold">Service Category</th>
                    <th className="py-3.5 px-4 font-bold">Payment Method</th>
                    <th className="py-3.5 px-4 font-bold">Transaction Reference/ID</th>
                    <th className="py-3.5 px-4 font-bold">Amount</th>
                    <th className="py-3.5 px-4 font-bold">Status</th>
                    <th className="py-3.5 px-4 font-bold text-center">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {requests.filter(r => r.payment.method).length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-12 text-center text-slate-500 font-semibold font-mono">
                        No transactions recorded inside the checkout gateway yet.
                      </td>
                    </tr>
                  ) : (
                    requests.filter(r => r.payment.method).map(req => {
                      return (
                        <tr key={req.id} className="hover:bg-slate-850">
                          <td className="py-4 px-4 font-mono font-bold text-orange-400">{req.id}</td>
                          <td className="py-4 px-4 font-semibold">{req.fullName}</td>
                          <td className="py-4 px-4 text-slate-400">{req.serviceType}</td>
                          <td className="py-4 px-4"><span className="bg-slate-850 px-2.5 py-1 rounded text-[10px] font-mono">{req.payment.method}</span></td>
                          <td className="py-4 px-4 font-mono text-slate-400 truncate max-w-[150px]" title={req.payment.transactionId}>
                            {req.payment.transactionId || 'Awaiting Input'}
                          </td>
                          <td className="py-4 px-4 font-bold text-white">₹{req.payment.amount || 150}</td>
                          <td className="py-4 px-4">
                            <span className={`text-[10px] font-mono font-black uppercase px-2 py-0.5 rounded ${
                              req.payment.status === 'Paid' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                            }`}>
                              {req.payment.status}
                            </span>
                          </td>
                          <td className="py-4 px-4 text-center">
                            {req.payment.status !== 'Paid' ? (
                              <div className="flex justify-center gap-1">
                                <button
                                  onClick={() => handleUpdatePaymentStatus(req.id, 'Paid')}
                                  className="bg-emerald-500 hover:bg-emerald-600 text-white px-2 py-1 text-[10px] rounded-md font-bold transition"
                                >
                                  Mark Approved
                                </button>
                                <button
                                  onClick={() => handleUpdatePaymentStatus(req.id, 'Failed')}
                                  className="bg-rose-500 hover:bg-rose-600 text-white px-2 py-1 text-[10px] rounded-md font-bold transition"
                                >
                                  Mark Reject
                                </button>
                              </div>
                            ) : (
                              <span className="text-slate-500">None required</span>
                            )}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* TAB 3: ADMIN LIVE CHAT WITH CUSTOMER SELECTOR */}
        {activeTab === 'chat' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-left">
            
            {/* Customer picking sidebar drawer */}
            <div className="lg:col-span-4 bg-slate-900 border border-slate-800 rounded-2xl p-4 space-y-4">
              <h4 className="font-bold text-slate-200 text-sm font-mono tracking-wider mb-2">📥 CHAT DIRECTORY</h4>
              
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {requests.length === 0 ? (
                  <p className="text-xs text-slate-500 font-mono text-center py-6">No users found.</p>
                ) : (
                  Array.from(new Set(requests.map(r => r.userId))).map(uid => {
                    const candidate = requests.find(r => r.userId === uid);
                    const name = candidate?.fullName || 'Anonymous';
                    const active = activeChatRecipientId === uid;
                    
                    return (
                      <div
                        key={uid}
                        onClick={() => {
                          setActiveChatRecipientId(uid);
                          setActiveChatRecipientName(name);
                        }}
                        className={`p-3 rounded-xl cursor-pointer text-left transition-all ${
                          active 
                            ? 'bg-orange-500/10 border border-orange-500/30 text-white font-sans' 
                            : 'bg-slate-950 hover:bg-slate-850 text-slate-300'
                        }`}
                      >
                        <p className="font-bold text-xs">{name}</p>
                        <p className="text-[10px] text-slate-500 mt-1 font-mono truncate">{candidate?.mobileNumber}</p>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* Chat support board viewport */}
            <div className="lg:col-span-8 flex flex-col justify-between">
              {activeChatRecipientId ? (
                <div>
                  <h3 className="text-sm font-semibold text-slate-300 mb-2 font-mono">
                    CHAT SESSION CONTEXT: <span className="text-orange-400 font-bold">{activeChatRecipientName}</span>
                  </h3>
                  <ChatSupport 
                    token={token} 
                    currentUser={user} 
                    adminSelectedRecipientId={activeChatRecipientId} 
                  />
                </div>
              ) : (
                <div className="bg-slate-900 border border-slate-800 p-12 text-center rounded-2xl h-[600px] flex flex-col items-center justify-center">
                  <MessageSquare className="w-12 h-12 text-slate-700 animate-bounce mb-3" />
                  <p className="text-sm font-bold text-slate-400">Select any chat partner context from the left directory to open dialogue.</p>
                </div>
              )}
            </div>

          </div>
        )}

        {/* TAB 4: REGISTERED CUSTOMERS DIRECTORY */}
        {activeTab === 'users' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-left space-y-4">
            <h3 className="text-lg font-bold font-display text-white flex items-center gap-2">
              <Users className="w-5 h-5 text-emerald-450 text-emerald-400" /> Registered Clients database ({usersList.length})
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {usersList.length === 0 ? (
                <p className="text-xs text-slate-500 font-mono col-span-3 text-center py-6">No users registered yet.</p>
              ) : (
                usersList.map((usr) => (
                  <div key={usr.id} className="bg-slate-950 p-4 rounded-xl border border-slate-850 flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-800 text-orange-400 flex items-center justify-center text-xs font-black font-sans">
                      CL
                    </div>
                    <div className="min-w-0 text-left">
                      <h4 className="font-bold text-white text-xs truncate" title={usr.name}>{usr.name}</h4>
                      <p className="text-[10px] text-slate-500 font-mono mt-0.5" title={usr.email}>Email: {usr.email}</p>
                      <p className="text-[10px] text-slate-400 font-mono" title={usr.mobile}>Phone: {usr.mobile}</p>
                      <p className="text-[9px] text-slate-500 font-mono mt-1">Join date: {new Date(usr.createdAt).toLocaleDateString()}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* TAB 5: WHATSAPP/EMAIL SYSTEM NOTIFICATIONS LOG */}
        {activeTab === 'notifications' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-left space-y-4">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-2">
              <div>
                <h3 className="text-xl font-bold font-display text-white flex items-center gap-2">
                  <Bell className="w-5 h-5 text-orange-400 animate-pulse" /> Alerts & Notifications Log
                </h3>
                <p className="text-[11px] text-slate-500 tracking-wide mt-1">
                  Log of status updates and notifications sent to customer mobile numbers and emails.
                </p>
              </div>

              <div className="flex items-center gap-1.5 bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-850 text-[10px] text-slate-400">
                <span className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-ping"></span>
                <span>System Active</span>
              </div>
            </div>

            <div className="space-y-3.5 max-h-[600px] overflow-y-auto pr-2">
              {notificationsLog.length === 0 ? (
                <p className="text-xs font-mono text-slate-500 text-center py-12">No dispatch entries present yet.</p>
              ) : (
                notificationsLog.map((log) => {
                  return (
                    <div key={log.id} className="bg-slate-950 rounded-xl border border-slate-850 p-4 space-y-2 max-w-full overflow-hidden text-slate-300">
                      
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-900 pb-2">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className={`text-[9px] font-mono font-black uppercase px-2 py-0.5 rounded ${
                            log.channel === 'WhatsApp' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/10' : 'bg-orange-500/10 text-orange-400 border border-orange-500/10'
                          }`}>
                            {log.channel}
                          </span>
                          <span className="text-[10px] font-mono font-extrabold text-orange-400">
                            {log.event}
                          </span>
                          <span className="text-[10px] text-slate-600 font-mono">
                            ID: {log.id}
                          </span>
                        </div>

                        <div className="flex items-center gap-2 text-[10px] font-mono text-slate-500">
                          <span>{new Date(log.timestamp).toLocaleTimeString()}</span>
                          <span className={`px-2 py-0.5 text-[9px] font-bold rounded ${
                            log.status === 'Sent' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-red-500/10 text-red-500'
                          }`}>
                            {log.status}
                          </span>
                        </div>
                      </div>

                      <div className="text-left py-1 text-xs font-mono bg-slate-900/40 p-3 rounded-lg border border-slate-850 max-h-24 overflow-y-auto select-all text-slate-400">
                        {log.content.includes('<div') ? (
                          // Strip simple tags or display directly
                          <div dangerouslySetInnerHTML={{ __html: log.content.replaceAll('\n', '<br>') }}></div>
                        ) : (
                          <p className="whitespace-pre-wrap">{log.content}</p>
                        )}
                      </div>

                      <p className="text-[10px] text-slate-500 font-mono">
                        Destination target address: <span className="text-slate-300 font-bold">{log.destination}</span>
                      </p>

                    </div>
                  );
                })
              )}
            </div>

          </div>
        )}

      </div>

    </div>
  );
}
