import React, { useState, useEffect, useRef } from 'react';
import { 
  Send, 
  Paperclip, 
  X, 
  FileText, 
  CheckCheck, 
  Check, 
  Bot, 
  User, 
  ShieldAlert, 
  CornerDownRight, 
  Loader2, 
  PhoneCall 
} from 'lucide-react';
import { ChatMessage, AttachedFile } from '../types';

interface ChatSupportProps {
  token: string | null;
  currentUser: { id: string; name: string; role: string } | null;
  adminSelectedRecipientId?: string | null; // Admins pick who they are messaging
}

export default function ChatSupport({ token, currentUser, adminSelectedRecipientId }: ChatSupportProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [inputText, setInputText] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [attachedFile, setAttachedFile] = useState<AttachedFile | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Recipient evaluation based on logged in role
  const chatPartnerId = currentUser?.role === 'admin' ? (adminSelectedRecipientId || '') : 'admin';

  const fetchMessages = async () => {
    if (!token || !currentUser) return;
    try {
      const resp = await fetch('/api/chat', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (resp.ok) {
        const data = await resp.json();
        setMessages(data);
        
        // Trigger API read receipt update
        await fetch('/api/chat/read', {
          method: 'PATCH',
          headers: { 
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          }
        });
      }
    } catch (e) {
      console.warn('Silent read or connection issue in chat client:', e);
    }
  };

  useEffect(() => {
    setIsLoading(true);
    fetchMessages().finally(() => setIsLoading(false));

    // Active polling interval for instant message simulation
    const interval = setInterval(() => {
      fetchMessages();
    }, 4500);

    return () => clearInterval(interval);
  }, [token, currentUser, adminSelectedRecipientId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, attachedFile]);

  // Handle uploaded attachment securely and convert to Base64
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Check size limit (6MB max base64 size is safe)
    if (file.size > 6 * 1024 * 1024) {
      alert('File exceeds safe upload limit of 6MB.');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setAttachedFile({
        name: file.name,
        type: file.type,
        size: file.size,
        content: reader.result as string
      });
    };
    reader.onerror = () => {
      alert('Error reading source file.');
    };
    reader.readAsDataURL(file);
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim() && !attachedFile) return;
    if (!token || !currentUser) return;

    setIsSending(true);
    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          text: inputText,
          file: attachedFile,
          recipientId: chatPartnerId
        })
      });

      if (response.ok) {
        const msg = await response.json();
        setMessages(prev => [...prev, msg]);
        setInputText('');
        setAttachedFile(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
      } else {
        const err = await response.json();
        alert(err.error || 'Failed to dispatch message.');
      }
    } catch (error) {
      alert('Network issue sending chat message.');
    } finally {
      setIsSending(false);
    }
  };

  const removeAttachment = () => {
    setAttachedFile(null);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  // Helper size formatter
  const formatSize = (bytes: number): string => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  // Get date stamp
  const formatTime = (isoString: string): string => {
    const d = new Date(isoString);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  // Filter messages specifically for the selected chat partner (Admin only looks at selected recipient)
  const conversationMessages = messages.filter(m => {
    if (currentUser?.role === 'admin') {
      return (m.senderId === chatPartnerId && m.recipientId === 'admin') ||
             (m.sender === 'admin' && m.recipientId === chatPartnerId);
    } else {
      // Customer sees all chats sent to or received from Admin
      return true;
    }
  });

  return (
    <div id="chat_system_container" className="flex flex-col h-[600px] rounded-2xl glass-panel relative overflow-hidden shadow-2xl transition-all duration-300">
      
      {/* Top Banner Header */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-indigo-950 px-6 py-4 flex items-center justify-between border-b border-slate-200 dark:border-slate-850">
        <div className="flex items-center gap-3">
          <div className="relative">
            <div className="w-10 h-10 rounded-full bg-indigo-600 dark:bg-indigo-500/80 flex items-center justify-center text-white font-semibold shadow-inner">
              {currentUser?.role === 'admin' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5 text-cyan-400" />}
            </div>
            <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-slate-900 rounded-full animate-pulse"></span>
          </div>
          <div>
            <h4 className="font-semibold text-white tracking-tight text-sm md:text-base">
              {currentUser?.role === 'admin' ? 'Messaging Customer' : 'Rupansh Online Support'}
            </h4>
            <p className="text-xs text-slate-400 font-mono">
              {currentUser?.role === 'admin' ? `ID: ${chatPartnerId || 'Select recipient'}` : 'Online • Instant Processing Help'}
            </p>
          </div>
        </div>
        
        {/* Dynamic call badge */}
        <div className="flex items-center gap-2">
          {currentUser?.role !== 'admin' && (
            <a href="tel:8130670350" className="bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-400 text-xs px-3 py-1.5 rounded-lg flex items-center gap-1.5 transition-all">
              <PhoneCall className="w-3.5 h-3.5" />
              <span className="hidden md:inline font-semibold">Call Shop</span>
            </a>
          )}
        </div>
      </div>

      {/* Messages Canvas Grid */}
      <div className="flex-1 bg-gradient-to-b from-slate-50/20 to-slate-100/50 dark:from-slate-900/40 dark:to-slate-950/40 p-4 md:p-6 overflow-y-auto space-y-4">
        {isLoading ? (
          <div className="flex flex-col items-center justify-center h-full gap-2">
            <Loader2 className="w-8 h-8 text-cyan-400 animate-spin" />
            <p className="text-xs text-slate-500 dark:text-slate-400">Loading chat... Please wait</p>
          </div>
        ) : conversationMessages.length === 0 ? (
          <div className="flex flex-col items-center justify-center text-center h-full p-6">
            <div className="w-14 h-14 rounded-2xl bg-indigo-50 dark:bg-slate-800 flex items-center justify-center text-indigo-500 dark:text-cyan-400 mb-4 animate-bounce">
              <Bot className="w-7 h-7" />
            </div>
            <p className="font-semibold text-slate-700 dark:text-slate-300">
              {currentUser?.role === 'admin' 
                ? 'Select a customer from the left sidebar or requests to start chatting.'
                : 'Welcome to Rupansh Online Solution Support!'}
            </p>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 max-w-sm">
              {currentUser?.role === 'admin'
                ? 'Select any user file link or start explaining requirements.' 
                : 'Send a message or details regarding your PAN, Aadhaar, Passport, or government forms. Our representatives reply instantly!'}
            </p>
          </div>
        ) : (
          conversationMessages.map((msg) => {
            const isMe = msg.senderId === currentUser?.id;
            return (
              <div 
                key={msg.id} 
                className={`flex flex-col max-w-[85%] sm:max-w-[75%] ${isMe ? 'ml-auto items-end' : 'mr-auto items-start'}`}
              >
                {/* Sender Title */}
                <div className="flex items-center gap-1.5 mb-1">
                  <span className="text-[10px] text-slate-400 font-medium">
                    {msg.senderName}
                  </span>
                  <span className="text-[9px] text-slate-400 font-mono">• {formatTime(msg.timestamp)}</span>
                </div>

                {/* Bubble card */}
                <div className={`px-4 py-2.5 rounded-2xl shadow-sm text-sm ${
                  isMe 
                    ? 'bg-gradient-to-r from-cyan-600 to-indigo-600 text-white rounded-tr-none' 
                    : 'bg-white dark:bg-slate-850 text-slate-800 dark:text-slate-100 border border-slate-100 dark:border-slate-800 rounded-tl-none'
                }`}>
                  {msg.text && <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>}

                  {/* Render attached files directly in the chat! */}
                  {msg.file && (
                    <div className={`mt-2 p-2.5 rounded-xl flex items-center gap-3 border ${
                      isMe 
                        ? 'bg-white/10 border-white/10 text-white' 
                        : 'bg-indigo-50/50 dark:bg-slate-800/80 border-indigo-100 dark:border-slate-700 text-slate-900 dark:text-slate-100'
                    }`}>
                      <div className="w-10 h-10 rounded-lg bg-indigo-600 flex items-center justify-center text-white flex-shrink-0 animate-pulse">
                        <FileText className="w-5 h-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-semibold truncate">{msg.file.name}</p>
                        <p className={`text-[10px] ${isMe ? 'text-indigo-200' : 'text-slate-500'}`}>
                          {formatSize(msg.file.size)}
                        </p>
                      </div>
                      
                      {/* Base64 Download Link */}
                      <a 
                        href={msg.file.content} 
                        download={msg.file.name}
                        className={`p-1.5 rounded-lg hover:bg-black/10 transition-colors text-xs font-mono`}
                        title="Download attached paper"
                      >
                        💾 Download
                      </a>
                    </div>
                  )}
                </div>

                {/* Read Receipt indicator */}
                {isMe && (
                  <div className="flex items-center gap-0.5 mt-0.5">
                    {msg.read ? (
                      <CheckCheck className="w-3.5 h-3.5 text-cyan-400" />
                    ) : (
                      <Check className="w-3.5 h-3.5 text-slate-400" />
                    )}
                    <span className="text-[9px] text-slate-400">
                      {msg.read ? 'Opened' : 'Delivered'}
                    </span>
                  </div>
                )}
              </div>
            );
          })
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input / Form Tray */}
      <form onSubmit={handleSendMessage} className="p-3 md:p-4 bg-white dark:bg-slate-900 border-t border-slate-200 dark:border-slate-800">
        
        {/* Expanded Preview attachment frame */}
        {attachedFile && (
          <div className="mb-3 p-2.5 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded-xl flex items-center justify-between animate-fade-in animate-float">
            <div className="flex items-center gap-2">
              <FileText className="w-5 h-5 text-indigo-400 flex-shrink-0" />
              <div className="text-left">
                <p className="text-xs font-semibold truncate max-w-[200px] text-slate-850 dark:text-slate-200">
                  {attachedFile.name}
                </p>
                <p className="text-[10px] text-slate-500">
                  {formatSize(attachedFile.size)}
                </p>
              </div>
            </div>
            <button 
              type="button" 
              onClick={removeAttachment}
              className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full transition-colors"
            >
              <X className="w-4 h-4 text-slate-400 hover:text-red-500" />
            </button>
          </div>
        )}

        {/* Input tray */}
        <div className="flex items-center gap-2">
          {/* File input invoker */}
          <button
            type="button"
            onClick={() => fileInputRef.current?.click()}
            className="p-2.5 text-slate-500 dark:text-slate-400 hover:text-indigo-500 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition-all"
            title="Attach a scan, photo or DOC receipt"
          >
            <Paperclip className="w-5 h-5" />
          </button>
          <input 
            type="file" 
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
            className="hidden"
          />

          <input
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder={
              currentUser?.role === 'admin' && !adminSelectedRecipientId
                ? 'Please select a recipient first...'
                : 'Ask our agent state solutions, requirements or update status...'
            }
            disabled={currentUser?.role === 'admin' && !adminSelectedRecipientId}
            className="flex-1 bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 focus:outline-none focus:ring-1 focus:ring-indigo-500 dark:text-white dark:placeholder-slate-500"
          />

          <button
            type="submit"
            disabled={isSending || (!inputText.trim() && !attachedFile) || (currentUser?.role === 'admin' && !adminSelectedRecipientId)}
            className="bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl p-2.5 shadow-md flex items-center justify-center transition-all disabled:opacity-40"
          >
            {isSending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Send className="w-5 h-5" />
            )}
          </button>
        </div>
        <p className="text-[10px] text-slate-400 mt-1.5 text-center">
          Files accepted: PDF, JPG, PNG, DOC, DOCX up to 6MB limits.
        </p>
      </form>

    </div>
  );
}
