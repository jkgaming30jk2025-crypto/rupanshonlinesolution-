import React, { useState, useEffect, useRef } from 'react';
import { 
  FileText, 
  Send, 
  Trash2, 
  Plus, 
  History, 
  MapPin, 
  ShieldAlert, 
  CreditCard, 
  UploadCloud, 
  MessageSquare, 
  LogOut, 
  User, 
  ExternalLink,
  Loader2, 
  Check, 
  TrendingUp, 
  FileCheck, 
  Clock, 
  QrCode, 
  Building,
  CheckCircle2,
  AlertCircle,
  X
} from 'lucide-react';
import { ServiceRequest, AttachedFile, RequestStatus } from '../types';
import { servicesList } from '../services';
import ChatSupport from './ChatSupport';

interface CustomerDashboardProps {
  token: string | null;
  user: { id: string; name: string; mobile: string; email: string; role: string } | null;
  onLogout: () => void;
}

export default function CustomerDashboard({ token, user, onLogout }: CustomerDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'new-request' | 'payments' | 'chat'>('overview');
  const [requests, setRequests] = useState<ServiceRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<ServiceRequest | null>(null);
  const [loading, setLoading] = useState(false);

  // Form State
  const [formFullName, setFormFullName] = useState(user?.name || '');
  const [formMobile, setFormMobile] = useState(user?.mobile || '');
  const [formEmail, setFormEmail] = useState(user?.email || '');
  const [formServiceType, setFormServiceType] = useState('');
  const [formDescription, setFormDescription] = useState('');
  const [formFile, setFormFile] = useState<AttachedFile | null>(null);

  // Form Errors and Successes
  const [formError, setFormError] = useState('');
  const [formSuccess, setFormSuccess] = useState('');
  const [submittingForm, setSubmittingForm] = useState(false);

  // Payment Form State
  const [submittingPayment, setSubmittingPayment] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'UPI QR' | 'Google Pay' | 'PhonePe' | 'Paytm' | 'Pay At Shop' | ''>('');
  const [paymentTxnId, setPaymentTxnId] = useState('');
  const [paymentAmount, setPaymentAmount] = useState<number>(150);
  const [paymentSuccessMsg, setPaymentSuccessMsg] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  const fetchCustomerData = async () => {
    if (!token) return;
    setLoading(true);
    try {
      const response = await fetch('/api/requests/customer', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setRequests(data);
      }
    } catch (e) {
      console.error('Error fetching data:', e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCustomerData();
  }, [token]);

  // Handle Drag-and-Drop and typical file upload converts to Base64
  const handleUploadedAttachment = (e: React.ChangeEvent<HTMLInputElement> | React.DragEvent<HTMLDivElement>) => {
    let file: File | undefined;
    
    if ('dataTransfer' in e) {
      e.preventDefault();
      file = e.dataTransfer.files?.[0];
    } else {
      file = e.target.files?.[0];
    }

    if (!file) return;

    // Type validation
    const allowedExtensions = ['pdf', 'png', 'jpg', 'jpeg', 'doc', 'docx'];
    const extension = file.name.split('.').pop()?.toLowerCase();
    if (!extension || !allowedExtensions.includes(extension)) {
      setFormError('Invalid file type! Allowed extensions: PDF, JPG, PNG, DOC, DOCX');
      return;
    }

    // Size check (6MB maximum)
    if (file.size > 6 * 1024 * 1024) {
      setFormError('File too large! Maximum allowed document attachment size is 6MB.');
      return;
    }

    setFormError('');
    const reader = new FileReader();
    reader.onload = () => {
      setFormFile({
        name: file!.name,
        type: file!.type,
        size: file!.size,
        content: reader.result as string
      });
    };
    reader.onerror = () => {
      setFormError('Could not process upload file on disk.');
    };
    reader.readAsDataURL(file);
  };

  const handleCreateRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    setFormSuccess('');

    // Validations
    if (!formFullName.trim()) return setFormError('Full Name is required.');
    if (!formMobile.trim()) return setFormError('Mobile Number is required.');
    if (!formEmail.trim()) return setFormError('Email Address is required.');
    if (!formServiceType) return setFormError('Please select a Service Card type.');
    if (!formDescription.trim()) return setFormError('Requirement description is required.');

    // Mobile validation
    const mobileRegex = /^[0-9]{10}$/;
    if (!mobileRegex.test(formMobile.trim())) {
      return setFormError('Invalid Mobile Number! Must be a exact 10-digit number.');
    }

    setSubmittingForm(true);

    try {
      const response = await fetch('/api/requests', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          fullName: formFullName,
          mobileNumber: formMobile,
          emailAddress: formEmail,
          serviceType: formServiceType,
          description: formDescription,
          file: formFile
        })
      });

      if (response.ok) {
        const data = await response.json();
        setFormSuccess(`Request successfully created! Ticket ID: ${data.id}`);
        setFormDescription('');
        setFormFile(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
        fetchCustomerData();
        // Shift context to overview to track the pending state
        setTimeout(() => {
          setActiveTab('overview');
          setFormSuccess('');
        }, 3000);
      } else {
        const err = await response.json();
        setFormError(err.error || 'Server error creating request.');
      }
    } catch (err) {
      setFormError('Network communication error.');
    } finally {
      setSubmittingForm(false);
    }
  };

  // UPI payment processing simulation with actual receipt verification
  const handleProcessPaymentSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRequest) return;
    if (!paymentMethod) {
      alert('Please choose a Payment Method!');
      return;
    }
    if (paymentMethod !== 'Pay At Shop' && !paymentTxnId.trim()) {
      alert('Please input your UPI / Wallet Transaction ID reference!');
      return;
    }

    setSubmittingPayment(true);
    try {
      const response = await fetch(`/api/requests/${selectedRequest.id}/payment`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          status: paymentMethod === 'Pay At Shop' ? 'Pending' : 'Paid',
          method: paymentMethod,
          transactionId: paymentMethod === 'Pay At Shop' ? 'Shop Clearance' : paymentTxnId,
          amount: paymentAmount
        })
      });

      if (response.ok) {
        const updated = await response.json();
        setPaymentSuccessMsg(`Receipt submitted successfully! State updated.`);
        setPaymentTxnId('');
        
        // Refresh requests lists
        const indx = requests.findIndex(r => r.id === updated.id);
        if (indx !== -1) {
          const updatedArr = [...requests];
          updatedArr[indx] = updated;
          setRequests(updatedArr);
          setSelectedRequest(updated);
        }

        setTimeout(() => {
          setPaymentSuccessMsg('');
        }, 4000);
      } else {
        alert('Could not update receipt records.');
      }
    } catch (e) {
      alert('Communication system timeout.');
    } finally {
      setSubmittingPayment(false);
    }
  };

  // Dynamic statistics calculations
  const totalSubmits = requests.length;
  const completedStats = requests.filter(r => r.status === 'Completed').length;
  const inProgressStats = requests.filter(r => r.status === 'In Progress' || r.status === 'Accepted').length;
  const pendingStats = requests.filter(r => r.status === 'Pending').length;

  return (
    <div id="customer_dashboard_layout" className="min-h-screen bg-slate-50 dark:bg-slate-950/80 transition-colors duration-200">
      
      {/* Visual cyber design decorations */}
      <div className="absolute top-20 right-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none animate-pulse-slow"></div>
      <div className="absolute bottom-20 left-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none animate-pulse-slow"></div>

      {/* Main Page Header */}
      <div className="bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-880 sticky top-0 z-40 transition-colors">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex flex-col md:flex-row items-center justify-between gap-4">
          
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-emerald-600 flex items-center justify-center text-white font-black text-xl shadow-md font-display">
              R
            </div>
            <div>
              <h1 className="text-xl md:text-2xl font-bold font-display text-slate-800 dark:text-slate-100 flex items-center gap-2">
                Customer Space <span className="text-xs bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 font-mono px-2 py-0.5 rounded-full font-bold">ACTIVE</span>
              </h1>
              <p className="text-sm text-slate-500 dark:text-slate-400 font-mono truncate max-w-[300px] md:max-w-none">
                Welcome back, <span className="text-emerald-600 dark:text-emerald-400 font-semibold">{user?.name}</span>
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3 w-full md:w-auto justify-end">
            <button 
              onClick={() => setActiveTab('new-request')}
              className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-semibold text-xs py-2 px-4 rounded-xl flex items-center gap-2 shadow-md hover:shadow-orange-500/10 transition-all h-10 w-full md:w-auto justify-center cursor-pointer"
            >
              <Plus className="w-4 h-4" /> New Ticket
            </button>

            <button
              onClick={onLogout}
              className="bg-slate-100 dark:bg-slate-800 hover:bg-red-500/20 dark:hover:bg-red-500/20 text-slate-700 dark:text-slate-300 hover:text-red-600 dark:hover:text-red-400 font-bold text-xs py-2 px-4 rounded-xl flex items-center gap-2 transition-all border border-slate-200 dark:border-slate-700 h-10 cursor-pointer"
              title="Logout current session securely"
            >
              <LogOut className="w-4 h-4" /> <span className="hidden md:inline">Sign Out</span>
            </button>
          </div>

        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        
        {/* Statistics Grid Widgets */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-8">
          
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl flex items-center gap-4 transition-all duration-300 shadow-sm hover:shadow">
            <div className="w-12 h-12 bg-emerald-50 dark:bg-slate-800 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 shadow-sm flex-shrink-0">
              <FileText className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-mono tracking-wider truncate">All Applications</p>
              <p className="text-xl md:text-3xl font-extrabold font-display dark:text-white mt-1">{totalSubmits}</p>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl flex items-center gap-4 transition-all duration-300 shadow-sm hover:shadow">
            <div className="w-12 h-12 bg-emerald-50 dark:bg-slate-800 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 shadow-sm flex-shrink-0">
              <Clock className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-mono tracking-wider truncate">Pending Audits</p>
              <p className="text-xl md:text-3xl font-extrabold font-display dark:text-white mt-1">{pendingStats}</p>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl flex items-center gap-4 transition-all duration-300 shadow-sm hover:shadow">
            <div className="w-12 h-12 bg-orange-50 dark:bg-slate-800 rounded-xl flex items-center justify-center text-orange-500 dark:text-orange-450 shadow-sm flex-shrink-0">
              <History className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-mono tracking-wider truncate">In Progress</p>
              <p className="text-xl md:text-3xl font-extrabold font-display dark:text-white mt-1">{inProgressStats}</p>
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-2xl flex items-center gap-4 transition-all duration-300 shadow-sm hover:shadow">
            <div className="w-12 h-12 bg-emerald-50 dark:bg-slate-800 rounded-xl flex items-center justify-center text-emerald-600 dark:text-emerald-400 shadow-sm flex-shrink-0">
              <FileCheck className="w-6 h-6" />
            </div>
            <div className="min-w-0">
              <p className="text-xs text-slate-500 dark:text-slate-400 uppercase font-mono tracking-wider truncate">Completed Cases</p>
              <p className="text-xl md:text-3xl font-extrabold font-display dark:text-white mt-1">{completedStats}</p>
            </div>
          </div>

        </div>

        {/* Dashboard Sections Toggle Navigation Bar */}
        <div className="flex border-b border-slate-200 dark:border-slate-800 mb-8 overflow-x-auto gap-2 md:gap-4 pb-2">
          
          <button
            onClick={() => setActiveTab('overview')}
            className={`cursor-pointer px-4 py-3 text-sm font-semibold whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'overview' 
                ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20' 
                : 'text-slate-600 dark:text-slate-400 hover:text-orange-500 hover:bg-slate-50 dark:hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            <History className="w-4 h-4" /> Application History
          </button>

          <button
            onClick={() => setActiveTab('new-request')}
            className={`cursor-pointer px-4 py-3 text-sm font-semibold whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'new-request' 
                ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20' 
                : 'text-slate-600 dark:text-slate-400 hover:text-orange-500 hover:bg-slate-50 dark:hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            <Plus className="w-4 h-4" /> Upload Documents
          </button>

          <button
            onClick={() => setActiveTab('payments')}
            className={`cursor-pointer px-4 py-3 text-sm font-semibold whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'payments' 
                ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20' 
                : 'text-slate-600 dark:text-slate-400 hover:text-orange-500 hover:bg-slate-50 dark:hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            <CreditCard className="w-4 h-4" /> Payment Center
          </button>

          <button
            onClick={() => setActiveTab('chat')}
            className={`cursor-pointer px-4 py-3 text-sm font-semibold whitespace-nowrap rounded-xl transition-all flex items-center gap-2 ${
              activeTab === 'chat' 
                ? 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border border-orange-500/20' 
                : 'text-slate-600 dark:text-slate-400 hover:text-orange-500 hover:bg-slate-50 dark:hover:bg-slate-900/60 border border-transparent'
            }`}
          >
            <MessageSquare className="w-4 h-4" /> Direct Live Chat Support
          </button>

        </div>

        {/* TAB 1: OVERVIEW & APPLICATION TRACKING TIMELINE */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Left requests list */}
            <div className="lg:col-span-2 space-y-4">
              <h3 className="text-lg font-bold font-display dark:text-white flex items-center gap-2">
                📂 Active digital tickets ({requests.length})
              </h3>

              {loading ? (
                <div className="flex justify-center items-center py-12">
                  <Loader2 className="w-8 h-8 text-orange-500 animate-spin" />
                </div>
              ) : requests.length === 0 ? (
                <div className="text-center py-12 px-6 glass-panel rounded-2xl border border-dashed border-slate-300 dark:border-slate-800">
                  <FileText className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                  <p className="font-semibold text-slate-700 dark:text-slate-300">No active applications found.</p>
                  <p className="text-xs text-slate-400 mt-1 max-w-xs mx-auto">Create a ticket using the &quot;Upload Documents&quot; form above to register your PAN, Aadhaar, Voter, or Passport forms!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {requests.map((req) => {
                    const isSelected = selectedRequest?.id === req.id;
                    return (
                      <div 
                        key={req.id}
                        onClick={() => setSelectedRequest(req)}
                        className={`p-5 rounded-2xl bg-white dark:bg-slate-900 border text-left cursor-pointer transition-all ${
                          isSelected 
                            ? 'ring-2 ring-orange-500 border-orange-500 bg-orange-500/5 shadow-md' 
                            : 'border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-850'
                        }`}
                      >
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                          <div>
                            <span className="font-mono text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-300 px-2 py-1 rounded-md">
                              {req.id}
                            </span>
                            <h4 className="font-bold dark:text-white mt-2 font-display text-base font-sans">
                              {req.serviceType}
                            </h4>
                            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 line-clamp-2">
                              {req.description}
                            </p>
                          </div>

                           <div className="flex flex-row sm:flex-col items-center sm:items-end justify-between sm:justify-center gap-2 flex-shrink-0">
                             
                             {/* Status label overrides */}
                             <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                               req.status === 'Completed' ? 'bg-emerald-500/10 text-emerald-500' :
                               req.status === 'In Progress' ? 'bg-orange-500/10 text-orange-550' :
                               req.status === 'Accepted' ? 'bg-emerald-500/10 text-emerald-600 dark:text-emerald-400' :
                               req.status === 'Rejected' ? 'bg-rose-500/10 text-rose-500' :
                               'bg-amber-500/10 text-amber-500'
                             }`}>
                              ● {req.status}
                            </span>

                            <span className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                              {new Date(req.createdAt).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                            </span>
                          </div>
                        </div>

                        {/* File preview line */}
                        {req.file && (
                          <div className="mt-3 text-xs bg-slate-100 dark:bg-slate-800 rounded-lg p-2 flex items-center gap-2 max-w-fit text-slate-600 dark:text-slate-300">
                            <FileText className="w-3.5 h-3.5 text-orange-500" />
                            <span className="truncate max-w-[150px] font-mono">{req.file.name}</span>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            {/* Right Interactive stepper & payment selector */}
            <div className="space-y-6">
              <h3 className="text-lg font-bold font-display dark:text-white flex items-center gap-2">
                🔍 Live Document tracking
              </h3>

              {selectedRequest ? (
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl text-left space-y-6 animate-fade-in relative shadow-sm hover:shadow">
                  
                  {/* Status track Card */}
                  <div>
                    <span className="font-mono text-xs text-slate-400">Selected receipt file</span>
                    <h4 className="text-base font-extrabold text-slate-800 dark:text-slate-200 mt-0.5 font-display flex items-center gap-2">
                      {selectedRequest.serviceType} <span className="text-xs bg-orange-500/10 text-orange-600 px-2 py-0.5 rounded-md font-mono font-bold">{selectedRequest.id}</span>
                    </h4>
                  </div>

                  {/* STEPPER TRACKING */}
                  <div className="space-y-6 relative before:absolute before:left-4 before:top-2 before:bottom-2 before:w-[2px] before:bg-slate-200 dark:before:bg-slate-800">
                    
                    {/* Step 1: Pending (always true) */}
                    <div className="flex items-start gap-3 relative z-10">
                      <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-xs shadow-md">
                        <Check className="w-4 h-4" />
                      </div>
                      <div>
                        <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Request submitted securely</p>
                        <p className="text-[10px] text-slate-500 font-mono">{new Date(selectedRequest.createdAt).toLocaleTimeString()}</p>
                      </div>
                    </div>

                    {/* Step 2: Accepted */}
                    {['Accepted', 'In Progress', 'Completed'].includes(selectedRequest.status) ? (
                      <div className="flex items-start gap-3 relative z-10">
                        <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-xs shadow-md">
                          <Check className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Accepted by Operator</p>
                          <p className="text-[10px] text-slate-400">Verification complete, forms generated</p>
                        </div>
                      </div>
                    ) : selectedRequest.status === 'Rejected' ? (
                      <div className="flex items-start gap-3 relative z-10">
                        <div className="w-8 h-8 rounded-full bg-red-500 text-white flex items-center justify-center font-bold text-xs shadow-md">
                          <X className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-red-500">Rejected / Insufficient Data</p>
                          <p className="text-[10px] text-slate-500">Please chat with support immediately to correct.</p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start gap-3 relative z-10">
                        <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-400 flex items-center justify-center font-bold text-xs">
                          2
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-slate-400">Accepted by Operator</p>
                          <p className="text-[10px] text-slate-400">Pending initial administrative review</p>
                        </div>
                      </div>
                    )}

                    {/* Step 3: In Progress */}
                    {['In Progress', 'Completed'].includes(selectedRequest.status) ? (
                      <div className="flex items-start gap-3 relative z-10">
                        <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-xs shadow-md">
                          <Check className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Form Submission in Progress</p>
                          <p className="text-[10px] text-slate-400">Server uploading to Government database</p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start gap-3 relative z-10">
                        <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-400 flex items-center justify-center font-bold text-xs">
                          3
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-slate-400">In Progress</p>
                          <p className="text-[10px] text-slate-400">Awaiting processing step execution</p>
                        </div>
                      </div>
                    )}

                    {/* Step 4: Completed */}
                    {selectedRequest.status === 'Completed' ? (
                      <div className="flex items-start gap-3 relative z-10">
                        <div className="w-8 h-8 rounded-full bg-emerald-500 text-white flex items-center justify-center font-bold text-xs shadow-md">
                          <Check className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800 dark:text-slate-200">Successfully Completed</p>
                          <p className="text-[10px] text-slate-400">Official digital document generated & ready for download</p>
                        </div>
                      </div>
                    ) : (
                      <div className="flex items-start gap-3 relative z-10">
                        <div className="w-8 h-8 rounded-full bg-slate-200 dark:bg-slate-800 text-slate-400 flex items-center justify-center font-bold text-xs">
                          4
                        </div>
                        <div>
                          <p className="text-xs font-semibold text-slate-400">Completed & Dispatched</p>
                          <p className="text-[10px] text-slate-400">Customer files will be available below</p>
                        </div>
                      </div>
                    )}

                  </div>

                  {/* Action box for payments inside tracker */}
                  <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-col gap-2">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-xs font-mono text-slate-400">Charge estimate:</span>
                      <span className="text-sm font-bold text-orange-500 font-sans">₹150.00</span>
                    </div>

                    <div className="flex justify-between items-center">
                      <span className="text-xs font-mono text-slate-400">Payment status:</span>
                      <span className={`text-xs font-bold px-2 py-0.5 rounded ${
                        selectedRequest.payment.status === 'Paid' ? 'bg-emerald-500/10 text-emerald-500' :
                        selectedRequest.payment.status === 'Failed' ? 'bg-red-500/10 text-red-500' :
                        'bg-amber-500/10 text-amber-500'
                      }`}>
                        {selectedRequest.payment.status}
                      </span>
                    </div>

                    {selectedRequest.payment.status !== 'Paid' && (
                      <button
                        onClick={() => {
                          setPaymentAmount(150);
                          setActiveTab('payments');
                        }}
                        className="mt-4 bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 font-bold text-xs text-white py-2.5 rounded-xl flex items-center justify-center gap-1 cursor-pointer transition-all shadow"
                      >
                        ⚡ Make Online UPI Payment Now
                      </button>
                    )}
                  </div>

                </div>
              ) : (
                <div className="glass-panel p-6 rounded-2xl text-center py-12 border border-dashed border-slate-300 dark:border-slate-800">
                  <MapPin className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                  <p className="text-xs text-slate-500 dark:text-slate-400">Select any ongoing active document application in the left list to fetch real-time state steppers, logs, and billing receipts.</p>
                </div>
              )}
            </div>

          </div>
        )}

        {/* TAB 2: REQUEST FORM / DOCUMENT UPLOAD WITH VALIDATIONS */}
        {activeTab === 'new-request' && (
          <div className="max-w-2xl mx-auto glass-panel p-6 md:p-8 rounded-2xl glow-cyan text-left">
            <h3 className="text-xl font-bold font-display dark:text-white flex items-center gap-2 mb-2">
              📝 Apply for online digital services
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-6">
              Please enter candidate details carefully. Original document scans are securely parsed, and encrypted in compliance with Delhi Digital Services protocols.
            </p>

            {formSuccess && (
              <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 rounded-xl flex items-center gap-3 animate-fade-in">
                <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
                <div className="text-sm">
                  <p className="font-bold">Form Submitted Successfully!</p>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-0.5">{formSuccess}</p>
                </div>
              </div>
            )}

            {formError && (
              <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl flex items-center gap-3 animate-fade-in">
                <AlertCircle className="w-5 h-5 flex-shrink-0" />
                <p className="text-xs font-semibold">{formError}</p>
              </div>
            )}

            <form onSubmit={handleCreateRequest} className="space-y-5">
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <div>
                  <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                    Candidate Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formFullName}
                    onChange={(e) => setFormFullName(e.target.value)}
                    placeholder="Enter full legal name"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white font-sans"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                    WhatsApp/Mobile Number *
                  </label>
                  <input
                    type="tel"
                    required
                    maxLength={10}
                    value={formMobile}
                    onChange={(e) => setFormMobile(e.target.value)}
                    placeholder="10-digit mobile number"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white font-sans"
                  />
                </div>

              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">

                <div>
                  <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    required
                    value={formEmail}
                    onChange={(e) => setFormEmail(e.target.value)}
                    placeholder="e.g. candidate@gmail.com"
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white font-sans"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                    Service Required *
                  </label>
                  <select
                    required
                    value={formServiceType}
                    onChange={(e) => setFormServiceType(e.target.value)}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white h-10 appearance-none bg-no-repeat font-sans"
                  >
                    <option value="">-- Choose Online Service --</option>
                    {servicesList.map(item => (
                      <option key={item.id} value={item.dbType}>
                        {item.title}
                      </option>
                    ))}
                  </select>
                </div>

              </div>

              <div>
                <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                  Service requirements description *
                </label>
                <textarea
                  required
                  rows={4}
                  value={formDescription}
                  onChange={(e) => setFormDescription(e.target.value)}
                  placeholder="Explain details (e.g., PAN DOB change from 1999 to 2000, or Aadhaar address sync request details...)"
                  className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white font-sans"
                />
              </div>

              {/* Secure Drag and Drop file upload */}
              <div>
                <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                  Upload Required Scans (Proof)
                </label>
                
                <div 
                  onDragOver={(e) => e.preventDefault()}
                   onDrop={handleUploadedAttachment}
                  className="border-2 border-dashed border-slate-300 dark:border-slate-700 hover:border-orange-500 rounded-2xl p-6 text-center cursor-pointer transition-colors bg-slate-50/50 dark:bg-slate-900/50"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleUploadedAttachment}
                    accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                    className="hidden"
                  />
                  <UploadCloud className="w-10 h-10 text-slate-400 mx-auto mb-2 animate-bounce" />
                  <p className="text-sm font-semibold text-slate-700 dark:text-slate-300">
                    Drag and drop file here, or click to browse
                  </p>
                  <p className="text-[10px] text-slate-400 mt-1 uppercase font-mono tracking-wider">
                    Accepted: PDF, PNG, JPG, JPEG, DOC, DOCX • Limit: 6MB
                  </p>
                </div>

                {formFile && (
                  <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-between text-emerald-600 dark:text-emerald-400 animate-slide-down">
                    <div className="flex items-center gap-2 min-w-0">
                      <FileText className="w-5 h-5 flex-shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs font-bold truncate max-w-[200px] text-slate-800 dark:text-slate-200">{formFile.name}</p>
                        <p className="text-[10px] text-slate-400">{(formFile.size / 1024).toFixed(1)} KB</p>
                      </div>
                    </div>
                    <button
                      type="button"
                      onClick={() => setFormFile(null)}
                      className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-full text-slate-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                )}
              </div>

              <div className="pt-4">
                <button
                  type="submit"
                  disabled={submittingForm}
                  className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-extrabold py-3 rounded-xl transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50 font-sans"
                >
                  {submittingForm ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" /> Verifying inputs...
                    </>
                  ) : (
                    <>
                      <Send className="w-4 h-4" /> Submit Application & Pay Later
                    </>
                  )}
                </button>
              </div>

            </form>
          </div>
        )}

        {/* TAB 3: PAYMENTS SECTION WITH CORRESPONDING UPI ID & SCAN METHOD */}
        {activeTab === 'payments' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
            
            {/* Left side selector */}
            <div className="lg:col-span-5 glass-panel p-6 rounded-2xl glow-cyan space-y-6">
              <h3 className="text-lg font-bold font-display dark:text-white flex items-center gap-2">
                 UPI QR Code Payment Card
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                Pick an unpaid ticket from your list, scan the UPI QR code on the right with GPay, PhonePe, Paytm, or BHIM apps, then fill in your reference details.
              </p>

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold font-mono dark:text-slate-300 uppercase tracking-wider mb-1.5">
                    1. Select Application Ticket
                  </label>
                  <select
                    value={selectedRequest?.id || ''}
                    onChange={(e) => {
                      const found = requests.find(r => r.id === e.target.value);
                      if (found) setSelectedRequest(found);
                    }}
                    className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white h-11 font-sans"
                  >
                    <option value="">-- Choose active application --</option>
                    {requests.map(r => (
                      <option key={r.id} value={r.id}>
                        {r.serviceType} ({r.id}) - {r.payment.status}
                      </option>
                    ))}
                  </select>
                </div>

                {selectedRequest ? (
                  <form onSubmit={handleProcessPaymentSubmit} className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-850 animate-fade-in">
                    
                    <div className="p-3.5 bg-emerald-500/5 rounded-xl border border-emerald-500/10 text-xs text-emerald-600 dark:text-emerald-400 space-y-2 font-sans">
                      <p><strong>Applying:</strong> {selectedRequest.serviceType}</p>
                      <p><strong>Standard Price:</strong> ₹{paymentAmount}</p>
                      <p><strong>Mobile:</strong> {selectedRequest.mobileNumber}</p>
                    </div>

                    <div>
                      <label className="block text-xs font-semibold font-mono dark:text-slate-300 uppercase tracking-wider mb-1.5">
                        2. Choose Payment Mode
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {['UPI QR', 'Google Pay', 'PhonePe', 'Paytm', 'Pay At Shop'].map(mode => (
                          <button
                            key={mode}
                            type="button"
                            onClick={() => {
                              setPaymentMethod(mode as any);
                              if (mode === 'Pay At Shop') {
                                setPaymentTxnId('Shop Clearance');
                              } else if (paymentTxnId === 'Shop Clearance') {
                                setPaymentTxnId('');
                              }
                            }}
                            className={`px-3 py-2 text-xs font-bold rounded-xl transition-all border text-center ${
                              paymentMethod === mode 
                                ? 'bg-orange-600 text-white border-orange-600 shadow-sm' 
                                : 'bg-slate-50 dark:bg-slate-850 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            {mode}
                          </button>
                        ))}
                      </div>
                    </div>

                    {paymentMethod !== 'Pay At Shop' && paymentMethod !== '' && (
                      <div>
                        <label className="block text-xs font-semibold font-mono dark:text-slate-300 uppercase tracking-wider mb-1.5">
                          3. Transaction ID *
                        </label>
                        <input
                          type="text"
                          required
                          value={paymentTxnId}
                          onChange={(e) => setPaymentTxnId(e.target.value)}
                          placeholder="UPI reference Ref/UTR No. (12 digits)"
                          className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white font-sans"
                        />
                      </div>
                    )}

                    {paymentSuccessMsg && (
                      <p className="text-xs text-emerald-500 font-semibold bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/20 flex items-center gap-1">
                        <Check className="w-4 h-4" /> {paymentSuccessMsg}
                      </p>
                    )}

                    <button
                      type="submit"
                      disabled={submittingPayment || !paymentMethod}
                      className="w-full bg-gradient-to-r from-emerald-600 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white font-extrabold py-3 text-xs rounded-xl shadow-md cursor-pointer transition-all flex items-center justify-center gap-2"
                    >
                      {submittingPayment ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin" /> Verifying payload data...
                        </>
                      ) : (
                        'Save Payment Receipt Reference'
                      )}
                    </button>

                  </form>
                ) : (
                  <div className="p-12 text-center bg-slate-50 dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                    <QrCode className="w-10 h-10 text-slate-400 mx-auto mb-2" />
                    <p className="text-xs text-slate-500">Pick any ongoing service application to continue with the checkout flow.</p>
                  </div>
                )}
              </div>
            </div>

            {/* Right side UPI QR Code visual graphic card */}
            <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-2xl flex flex-col items-center justify-center text-center relative overflow-hidden shadow-sm">
              
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-bl from-emerald-500/10 to-transparent rounded-bl-full animate-pulse"></div>

              {/* Title brand heading */}
              <div className="mb-4">
                <h4 className="font-extrabold text-emerald-700 dark:text-emerald-400 font-display text-lg">Rupansh Online Solution</h4>
                <p className="text-[11px] text-slate-500 font-mono">Scan using GooglePay, GPay, PhonePe, Paytm, BHIM</p>
              </div>

              {/* QR Code Container styled with neon glows matching the attached file */}
              <div className="bg-white p-6 rounded-3xl shadow-xl flex flex-col items-center border border-slate-200 max-w-[320px] mx-auto shadow-emerald-500/5">
                
                {/* Blue header wrapper */}
                <div className="flex items-center justify-center gap-1.5 mb-4">
                  <span className="text-blue-600 font-black text-xs font-mono">paytm</span>
                  <span className="text-red-500 text-xs">❤️</span>
                  <span className="text-blue-900 font-extrabold text-xs font-mono">UPI</span>
                </div>

                {/* Simulated high-fidelity UPI QR Graphic matching 8287738592@pthdfc */}
                <div className="relative mb-4 w-52 h-52 bg-gradient-to-tr from-sky-100 to-slate-200 rounded-2xl flex items-center justify-center border-4 border-slate-900 overflow-hidden shadow-inner">
                  
                  {/* Fake QR pattern rendered dynamically using SVGs */}
                  <div className="absolute inset-2 grid grid-cols-4 grid-rows-4 gap-1 transform rotate-180 opacity-90">
                    <div className="bg-slate-950 rounded-sm"></div>
                    <div className="bg-slate-950 rounded-sm"></div>
                    <div className="bg-transparent"></div>
                    <div className="bg-slate-950 rounded-sm"></div>
                    
                    <div className="bg-transparent"></div>
                    <div className="bg-slate-950 rounded-sm"></div>
                    <div className="bg-slate-950 rounded-sm"></div>
                    <div className="bg-transparent"></div>
                    
                    <div className="bg-slate-950 rounded-sm"></div>
                    <div className="bg-transparent"></div>
                    <div className="bg-slate-950 rounded-sm"></div>
                    <div className="bg-slate-950 rounded-sm"></div>
                    
                    <div className="bg-slate-950 rounded-sm"></div>
                    <div className="bg-slate-950 rounded-sm"></div>
                    <div className="bg-transparent"></div>
                    <div className="bg-slate-950 rounded-sm"></div>
                  </div>

                  {/* Corner Target Squares */}
                  <div className="absolute top-2 left-2 w-12 h-12 bg-white border-[6px] border-slate-900 flex items-center justify-center">
                    <div className="w-5 h-5 bg-slate-900"></div>
                  </div>
                  <div className="absolute top-2 right-2 w-12 h-12 bg-white border-[6px] border-slate-900 flex items-center justify-center">
                    <div className="w-5 h-5 bg-slate-900"></div>
                  </div>
                  <div className="absolute bottom-2 left-2 w-12 h-12 bg-white border-[6px] border-slate-900 flex items-center justify-center">
                    <div className="w-5 h-5 bg-slate-900"></div>
                  </div>

                  {/* Central branding logo */}
                  <div className="absolute bg-white p-1 rounded-lg border border-slate-200">
                    <span className="text-[12px] font-black font-display tracking-tight text-blue-900">R</span>
                  </div>

                  {/* Laser scanning animations */}
                  <div className="absolute left-0 right-0 h-[3px] bg-orange-500 shadow-lg shadow-orange-500/50 animate-bounce"></div>

                </div>

                {/* VPA Address */}
                <p className="text-xs font-black text-slate-800 font-mono tracking-wide">
                  🔗 8287738592@pthdfc
                </p>

                <p className="text-[10px] text-slate-500 font-mono mt-1">
                  Merchant: Rupansh
                </p>

              </div>

              {/* Instructions list summary */}
              <div className="mt-6 max-w-sm space-y-2.5 text-xs text-slate-600 dark:text-slate-400">
                <p className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" /> Pay only the standard card charge fee limit (₹150).
                </p>
                <p className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" /> Note the Ref / UTR / Transaction number carefully.
                </p>
                <p className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" /> Await admin verification check (usually completed in minutes).
                </p>
              </div>

            </div>

          </div>
        )}

        {/* TAB 4: CHAT WITH ADMIN MODULE LINKED DIRECTLY */}
        {activeTab === 'chat' && (
          <div className="max-w-4xl mx-auto">
            <h3 className="text-lg font-bold font-display dark:text-white mb-4 text-left">
              💬 Direct Secure Live Chat with Operator
            </h3>
            <ChatSupport token={token} currentUser={user} />
          </div>
        )}

      </div>
    </div>
  );
}
