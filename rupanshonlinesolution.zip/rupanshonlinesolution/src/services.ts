import { 
  FileText, 
  CreditCard, 
  HeartHandshake, 
  Map, 
  TrendingUp, 
  Train, 
  Receipt, 
  Briefcase, 
  Settings, 
  BookOpen, 
  Layers 
} from 'lucide-react';

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  priceEstimate: string;
  completionTime: string;
  requiredDocuments: string[];
  color: string;
  dbType: string;
}

export const servicesList: ServiceItem[] = [
  {
    id: 'pan',
    title: 'PAN Card Services',
    description: 'Fresh Permanent Account Number applications, instant corrections, major details change, minor to major conversion, and biometric PAN verification links.',
    priceEstimate: '₹150 - ₹200',
    completionTime: '3-7 working days',
    requiredDocuments: ['Aadhaar Card copy', '2 passport photos', 'Mobile number linked with Aadhaar'],
    color: 'from-cyan-500 to-blue-600',
    dbType: 'PAN Card Services'
  },
  {
    id: 'aadhaar',
    title: 'Aadhaar Services',
    description: 'Dynamic mobile mapping assistance, address updates, print-out from original UID, demographic updates tracking, and child enrollment guides.',
    priceEstimate: '₹50 - ₹100',
    completionTime: '1-3 working days',
    requiredDocuments: ['Self-declaration form / Proof of Address', 'Identity Proof', 'Active phone number'],
    color: 'from-purple-500 to-indigo-600',
    dbType: 'Aadhaar Services'
  },
  {
    id: 'voter',
    title: 'Voter ID Services',
    description: 'State voter list enlistment, corrections, EPIC smart card download portal, polling station migration forms, and name deletion requests.',
    priceEstimate: '₹75 - ₹100',
    completionTime: '5-10 working days',
    requiredDocuments: ['Proof of Age (Aadhaar/10th Certificate)', 'Proof of Address (Utility bill/Aadhaar)', 'Passport photo'],
    color: 'from-blue-500 to-sky-600',
    dbType: 'Voter ID Services'
  },
  {
    id: 'passport',
    title: 'Passport Assistance',
    description: 'Tatkaal / Normal passport fresh registration, documentation pre-verification, appointment scheduling help, and file status notification updates.',
    priceEstimate: '₹350 - ₹500 (Service fee only)',
    completionTime: 'Instant appointment booking',
    requiredDocuments: ['10th Marksheet/Non-ECR proof', 'Aadhaar Card', 'Parental Details', 'Two Address Proofs'],
    color: 'from-indigo-600 to-violet-700',
    dbType: 'Passport Assistance'
  },
  {
    id: 'railway',
    title: 'Railway Ticket Booking',
    description: 'Authorized IRCTC ticket reservations, alternative route booking, instant Tatkaal reservations assistance, cancelations, and real-time live running status updates.',
    priceEstimate: 'Standard ticket price + minimal portal charge',
    completionTime: 'Within 5-15 mins',
    requiredDocuments: ['Traveler Full Names & Ages', 'Date of Travel', 'Valid ID Proof number'],
    color: 'from-emerald-500 to-teal-600',
    dbType: 'Railway Ticket Booking'
  },
  {
    id: 'billpay',
    title: 'Bill Payments',
    description: 'Instant verification of Electricity, Water, Broadband WIFI, Piped gas connections bills, Landline, Mobile, and Fastag recharges.',
    priceEstimate: 'No charge / minimal bill processing fee',
    completionTime: 'Instant confirmation',
    requiredDocuments: ['Consumer number / Connection account ID', 'Last pending bill copy (Optional)'],
    color: 'from-orange-500 to-red-600',
    dbType: 'Bill Payments'
  },
  {
    id: 'resume',
    title: 'Resume Creation',
    description: 'Modern, ATS-scannable resume designs, corporate CV alignments, cover letter structures, tailored job roles templates creation, and PDF layout styling.',
    priceEstimate: '₹150 - ₹300',
    completionTime: 'Within 2 hours',
    requiredDocuments: ['Qualifications details', 'Past experience timeline', 'Personal profile summary'],
    color: 'from-pink-500 to-rose-600',
    dbType: 'Resume Creation'
  },
  {
    id: 'govt',
    title: 'Government Form Filling',
    description: 'Reliable entry for SSC, Banking, Railways, State PSU recruitment forms, educational entrance exams, and scholarships portals applications.',
    priceEstimate: '₹80 - ₹150',
    completionTime: 'Within 24 hours',
    requiredDocuments: ['Candidate qualifications details', 'Passport Photo (Specific pixel sizes)', 'Signature scans'],
    color: 'from-gray-700 to-slate-900',
    dbType: 'Government Form Filling'
  },
  {
    id: 'print',
    title: 'Document Printing & Scanning',
    description: 'Lamination, heavy high-speed laser prints (Color & Black & White), legal-sized scan uploads, bookbinding prep, and digital optical character recognition.',
    priceEstimate: '₹3 - ₹20 per page',
    completionTime: 'On the spot',
    requiredDocuments: ['Source soft copies (PDF, JPG, Docx)', 'Pen-drive or secure digital link'],
    color: 'from-teal-500 to-green-600',
    dbType: 'Document Printing & Scanning'
  },
  {
    id: 'online_apps',
    title: 'Online Applications',
    description: 'Driving License slots, Caste/Income/Domicile certificates application, PVC smart cards portal access, and business MSME registration programs.',
    priceEstimate: '₹100 - ₹250',
    completionTime: '2-4 working days',
    requiredDocuments: ['Varies by application type (Contact Us or chat directly)'],
    color: 'from-amber-500 to-orange-600',
    dbType: 'Online Applications'
  },
  {
    id: 'other',
    title: 'Other Services',
    description: 'Digital Signature certificates, customized typing services (English & Hindi), PAN card biometric updates access, and fast custom internet surfing solutions.',
    priceEstimate: 'Discussed on request details',
    completionTime: 'Varies',
    requiredDocuments: ['Relevant specific papers'],
    color: 'from-slate-600 to-neutral-800',
    dbType: 'Other Services'
  }
];
