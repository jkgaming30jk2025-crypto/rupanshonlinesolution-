export type RequestStatus = 'Pending' | 'Accepted' | 'Rejected' | 'In Progress' | 'Completed';

export interface User {
  id: string;
  name: string;
  mobile: string;
  email: string;
  password?: string;
  createdAt: string;
}

export interface AttachedFile {
  name: string;
  type: string;
  size: number;
  content: string; // Base64 content data
}

export interface PaymentInfo {
  status: 'Pending' | 'Paid' | 'Failed';
  method: 'UPI QR' | 'Google Pay' | 'PhonePe' | 'Paytm' | 'Pay At Shop' | '';
  transactionId?: string;
  amount?: number;
  updatedAt?: string;
}

export interface ServiceRequest {
  id: string;
  userId: string;
  fullName: string;
  mobileNumber: string;
  emailAddress: string;
  serviceType: string;
  description: string;
  file?: AttachedFile;
  status: RequestStatus;
  createdAt: string;
  payment: PaymentInfo;
}

export interface ChatMessage {
  id: string;
  sender: 'customer' | 'admin';
  senderId: string;
  senderName: string;
  text: string;
  file?: AttachedFile;
  timestamp: string;
  read: boolean;
}

export interface DashboardStats {
  totalRequests: number;
  pendingRequests: number;
  acceptedRequests: number;
  completedRequests: number;
  todayRequests: number;
  totalCustomers: number;
  revenue: number;
}
