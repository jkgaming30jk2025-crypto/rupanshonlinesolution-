import React, { useState, useEffect } from 'react';
import { 
  FileText, 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Compass, 
  Users, 
  HelpCircle, 
  MessageSquare, 
  CreditCard, 
  QrCode, 
  CheckCircle2, 
  Lock, 
  Sun, 
  Moon, 
  ArrowRight, 
  Menu, 
  X, 
  Loader2, 
  TrendingUp, 
  ShieldAlert, 
  ChevronDown, 
  UserPlus, 
  ChevronRight,
  Sparkles,
  Award,
  BookOpen,
  Briefcase
} from 'lucide-react';
import { servicesList, ServiceItem } from './services';
import CustomerDashboard from './components/CustomerDashboard';
import AdminDashboard from './components/AdminDashboard';

export default function App() {
  // Theme state
  const [darkMode] = useState<boolean>(true);

  // Auth & View routing state
  const [authToken, setAuthToken] = useState<string | null>(() => localStorage.getItem('authToken'));
  const [currentUser, setCurrentUser] = useState<any>(() => {
    const saved = localStorage.getItem('sysUser');
    return saved ? JSON.parse(saved) : null;
  });
  
  const [pageView, setPageView] = useState<'home' | 'dashboard'>('home');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // General FAQ accordion index
  const [activeFaq, setActiveFaq] = useState<number | null>(null);

  // Active Testimonials Slider index
  const [testimonialIndex, setTestimonialIndex] = useState(0);

  // Login Modal State
  const [loginModalOpen, setLoginModalOpen] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [loginMobile, setLoginMobile] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [modalError, setModalError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);

  // Contact Page Form State
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactSubject, setContactSubject] = useState('');
  const [contactMessage, setContactMessage] = useState('');
  const [contactSuccess, setContactSuccess] = useState(false);

  // Expanded Service Card Details Modal state
  const [activeDetailService, setActiveDetailService] = useState<ServiceItem | null>(null);

  // Apply Dark theme classes on render
  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.add('dark');
    localStorage.setItem('theme', 'dark');
  }, [darkMode]);

  // Handle Token Authenticate Persistence
  const loginSessionSave = (token: string, userObj: any) => {
    localStorage.setItem('authToken', token);
    localStorage.setItem('sysUser', JSON.stringify(userObj));
    setAuthToken(token);
    setCurrentUser(userObj);
    setPageView('dashboard');
    setLoginModalOpen(false);
  };

  const handleLogoutAction = () => {
    localStorage.removeItem('authToken');
    localStorage.removeItem('sysUser');
    setAuthToken(null);
    setCurrentUser(null);
    setPageView('home');
  };

  // Perform Register / Login Submit API
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setModalError('');
    setAuthLoading(true);

    const targetUrl = isRegistering ? '/api/auth/register' : '/api/auth/login';
    const payload = isRegistering 
      ? { name: regName, mobile: loginMobile, email: regEmail, password: loginPassword }
      : { mobile: loginMobile, password: loginPassword };

    // Strict basic mobile validation
    if (!loginMobile.match(/^[0-9]{10}$/)) {
      setModalError('Invalid Mobile Number! Enter exact 10 digits.');
      setAuthLoading(false);
      return;
    }

    try {
      const response = await fetch(targetUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      if (response.ok) {
        const data = await response.json();
        loginSessionSave(data.token, data.user);
        
        // Reset states
        setLoginMobile('');
        setLoginPassword('');
        setRegName('');
        setRegEmail('');
      } else {
        const err = await response.json();
        setModalError(err.error || 'Authentication failure. Check inputs.');
      }
    } catch (err) {
      setModalError('Connection offline or server down.');
    } finally {
      setAuthLoading(false);
    }
  };

  // Contact Form Submission Action
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactPhone || !contactMessage) return;
    
    // Simple verification
    setContactSuccess(true);
    setContactName('');
    setContactPhone('');
    setContactSubject('');
    setContactMessage('');
    setTimeout(() => setContactSuccess(false), 5000);
  };

  // Testimonial sliders details
  const testimonials = [
    { name: "Rahul Sharma", role: "Local Merchant", feedback: "Rupansh Online Solution made PAN card applications extremely easy. Within 5 days I got the official PVC PAN tracking details. Outstanding service!" },
    { name: "Sunita Devi", role: "Student Candidate", feedback: "Excellent assistance with railway tatkaal booking and government PSU form uploads. Very fast, reliable, and professional support." },
    { name: "Amit Kapoor", role: "Resident of Karala", feedback: "The online ticket tracking system and direct chat support are fantastic features. Highly transparent, clean billing, and no redundant costs." }
  ];

  const handleNextTestimonial = () => {
    setTestimonialIndex((prev) => (prev + 1) % testimonials.length);
  };

  const handlePrevTestimonial = () => {
    setTestimonialIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  // Automated rotate cycle for testimonials
  useEffect(() => {
    const timer = setInterval(() => {
      handleNextTestimonial();
    }, 8000);
    return () => clearInterval(timer);
  }, []);

  const faqs = [
    { q: "What documents are required to apply for a fresh PAN Card?", a: "A copy of your Aadhaar Card with its mobile number linked is standard. Additionally, you will need two matching physical passport-size photographs of the applicant." },
    { q: "How can I track the progress status of my Government Exam Form?", a: "Once submitted, the Operator allocates a tracking Ticket ID. You can sign in to your dashboard to view the step-by-step progress, including scans and payment confirmations." },
    { q: "How do I make the payment for my applications?", a: "We support instant online UPI scans (Paytm, GPay, G-Pay, PhonePe QR) directly in the dashboard, or you can choose 'Pay At Shop' and settle the balance securely in person!" },
    { q: "Can I download my finalized PDF files directly?", a: "Yes! Both the customer panel and operator chat allow instant download of generated PDFs, scans, receipts, and proofs securely from any browser." }
  ];

  return (
    <div className={`min-h-screen text-slate-800 dark:text-slate-100 bg-slate-50 dark:bg-slate-950 font-sans transition-colors duration-300 relative overflow-x-hidden pt-1`}>
      
      {/* Dynamic Animated subtle particle effects on landing home page */}
      {pageView === 'home' && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
          <div className="absolute top-20 left-10 w-4 h-4 rounded-full bg-cyan-400 opacity-20 animate-float"></div>
          <div className="absolute top-1/3 right-12 w-6 h-6 rounded-full bg-indigo-500 opacity-20 animate-float" style={{ animationDelay: '2s' }}></div>
          <div className="absolute bottom-1/4 left-1/5 w-8 h-8 rounded-full bg-purple-500 opacity-15 animate-float" style={{ animationDelay: '4s' }}></div>
          <div className="absolute top-10 right-1/4 w-32 h-32 bg-cyan-500/5 rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-10 left-1/3 w-40 h-40 bg-purple-600/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '3s' }}></div>
        </div>
      )}

      {/* Floating WhatsApp Action badge with clean heartbeat pulse */}
      <a 
        href="https://wa.me/918130670350" 
        target="_blank" 
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 bg-emerald-500 text-white p-4 rounded-full shadow-2xl hover:scale-110 active:scale-90 transition-all cursor-pointer flex items-center justify-center border-2 border-emerald-400 animate-float"
        title="Chat on WhatsApp with Rupansh"
      >
        <span className="absolute inset-0 rounded-full animate-ping bg-emerald-500 opacity-60"></span>
        <svg xmlns="http://www.w3.org/2000/svg" className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.003 5.324 5.328 0 11.91 0c3.19.001 6.189 1.242 8.444 3.498c2.256 2.255 3.497 5.253 3.497 8.444c-.004 6.586-5.329 11.91-11.911 11.91c-1.996-.001-3.957-.5-5.69-1.448L0 24zm6.59-4.846c1.6.95 3.1 1.448 4.7.1c.142.084.285.168.43.25c1.55.91 3.12 1.38 4.72 1.38c5.44 0 9.87-4.42 9.87-9.87c0-2.64-1.03-5.11-2.89-6.97C16.85 2.05 14.38 1.02 11.74 1.02C6.31 1.02 1.88 5.44 1.88 10.88c0 2.06.51 4.07 1.48 5.8l.19.34l-1.0 3.65l3.7-.97l.32.19c1.65.98 3.5 1.5 5.39 1.5l.08-.11z" />
        </svg>
      </a>

      {/* Primary Top Navigation bar */}
      <nav id="navbar" className="glass-panel sticky top-0 z-50 shadow-sm border-b border-slate-200 dark:border-slate-800 transition-colors backdrop-blur-md">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 md:h-20">
            
            {/* Logo area */}
            <div className="flex items-center gap-2 md:gap-3 cursor-pointer" onClick={() => setPageView('home')}>
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-600 to-green-600 flex items-center justify-center text-white font-extrabold text-base md:text-lg shadow-md tracking-tight font-display animate-pulse">
                ROS
              </div>
              <div className="text-left">
                <span className="block text-sm md:text-base font-extrabold tracking-tight font-display text-slate-800 dark:text-slate-100 uppercase">
                  Rupansh Online Solution
                </span>
                <span className="block text-[9px] text-emerald-600 dark:text-emerald-450 font-mono tracking-widest uppercase">
                  Digital E-Services Portal
                </span>
              </div>
            </div>

            {/* Desktop link navigation */}
            <div className="hidden lg:flex items-center gap-8">
              <a href="#hero_section" className="text-xs font-semibold tracking-wider font-mono text-slate-600 dark:text-slate-350 hover:text-orange-500 transition-colors">HOME</a>
              <a href="#services_section" className="text-xs font-semibold tracking-wider font-mono text-slate-600 dark:text-slate-350 hover:text-orange-500 transition-colors">SERVICES</a>
              <a href="#why_choose_us" className="text-xs font-semibold tracking-wider font-mono text-slate-600 dark:text-slate-350 hover:text-orange-500 transition-colors">ADVANTAGES</a>
              <a href="#faq_section" className="text-xs font-semibold tracking-wider font-mono text-slate-600 dark:text-slate-350 hover:text-orange-500 transition-colors">FAQS</a>
              <a href="#contact_section" className="text-xs font-semibold tracking-wider font-mono text-slate-600 dark:text-slate-350 hover:text-orange-500 transition-colors">LOCATION & GET IN TOUCH</a>
            </div>

            {/* Right CTAs and toggles */}
            <div className="hidden lg:flex items-center gap-4">
              


              {authToken ? (
                <div className="flex items-center gap-3">
                  <button 
                    onClick={() => setPageView(pageView === 'home' ? 'dashboard' : 'home')}
                    className="bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs px-4 py-2.5 rounded-xl shadow-lg shadow-orange-500/20 transition-all cursor-pointer"
                  >
                    {pageView === 'home' ? 'Go to Active Space 💻' : 'View Home Page'}
                  </button>

                  <button 
                    onClick={handleLogoutAction}
                    className="bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-200 font-bold text-xs px-4 py-2.5 rounded-xl transition-all cursor-pointer"
                  >
                    Logout
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setIsRegistering(false);
                      setLoginModalOpen(true);
                    }}
                    className="text-xs font-extrabold text-slate-600 dark:text-slate-300 hover:text-orange-500 px-4 py-2 bg-slate-100 dark:bg-slate-900 rounded-xl transition cursor-pointer"
                  >
                    Sign In
                  </button>
                  <button
                    onClick={() => {
                      setIsRegistering(true);
                      setLoginModalOpen(true);
                    }}
                    className="bg-gradient-to-r from-orange-500 to-amber-600 hover:from-orange-600 hover:to-amber-700 text-white font-extrabold text-xs px-5 py-2.5 rounded-xl shadow-md shadow-orange-500/10 transition-all cursor-pointer"
                  >
                    Create Account
                  </button>
                </div>
              )}

            </div>

            {/* Mobile dynamic button controller */}
            <div className="flex lg:hidden items-center gap-3">


              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-1.5 rounded-lg text-slate-700 dark:text-slate-200 bg-slate-100 dark:bg-slate-900"
                aria-label="Toggle mobile drawer"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>

          </div>
        </div>

        {/* Mobile menu slideout tray navigation */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-slate-200 dark:border-slate-850 bg-white dark:bg-slate-950 p-4 space-y-3 shadow-xl text-left animate-slide-down">
            <a 
              href="#hero_section" 
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 rounded-lg"
            >
              HOME
            </a>
            <a 
              href="#services_section" 
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 rounded-lg"
            >
              ONLINE SERVICES
            </a>
            <a 
              href="#why_choose_us" 
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 rounded-lg"
            >
              ADVANTAGES
            </a>
            <a 
              href="#faq_section" 
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 rounded-lg"
            >
              FAQS
            </a>
            <a 
              href="#contact_section" 
              onClick={() => setMobileMenuOpen(false)}
              className="block px-3 py-2 text-sm font-semibold text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-900 rounded-lg"
            >
              LOCATION & GET IN TOUCH
            </a>

            <hr className="border-slate-200 dark:border-slate-800 my-2" />

            {authToken ? (
              <div className="flex flex-col gap-2 pt-1 pb-2">
                <button
                  onClick={() => {
                    setPageView(pageView === 'home' ? 'dashboard' : 'home');
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-center bg-indigo-600 text-white font-bold text-sm py-2 px-4 rounded-xl shadow cursor-pointer"
                >
                  {pageView === 'home' ? 'Open Dashboard Panel' : 'Go Back to Home'}
                </button>
                <button
                  onClick={() => {
                    handleLogoutAction();
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-center bg-slate-100 dark:bg-slate-900 text-slate-700 dark:text-slate-200 border dark:border-slate-800 font-bold text-sm py-2 px-4 rounded-xl cursor-pointer"
                >
                  Log Out Session
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-2 pt-1 pb-2">
                <button
                  onClick={() => {
                    setIsRegistering(false);
                    setLoginModalOpen(true);
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-center bg-slate-100 dark:bg-slate-900 dark:text-white border dark:border-slate-800 font-bold text-sm py-2.5 rounded-xl cursor-pointer"
                >
                  Secure Log In
                </button>
                <button
                  onClick={() => {
                    setIsRegistering(true);
                    setLoginModalOpen(true);
                    setMobileMenuOpen(false);
                  }}
                  className="w-full text-center bg-gradient-to-r from-cyan-600 to-indigo-600 text-white font-bold text-sm py-2.5 rounded-xl shadow cursor-pointer"
                >
                  Register Fresh Account
                </button>
              </div>
            )}
          </div>
        )}
      </nav>

      {/* RENDER VIEW SWITCHER: HOME (Landing Page) vs DASHBOARDS (Customer/Admin Space) */}
      {pageView === 'dashboard' && authToken ? (
        currentUser?.role === 'admin' ? (
          <AdminDashboard token={authToken} user={currentUser} onLogout={handleLogoutAction} />
        ) : (
          <CustomerDashboard token={authToken} user={currentUser} onLogout={handleLogoutAction} />
        )
      ) : (
        /* HOME LANDING VIEW */
        <div id="home_landing_canvas" className="animate-fade-in">
          
          {/* Neon scrollable ticker updates banner marquee */}
          <div className="bg-emerald-900 text-white py-2 overflow-hidden border-b border-emerald-500/20 z-10 relative">
            <div className="whitespace-nowrap inline-flex gap-16 text-[10px] md:text-xs font-mono tracking-widest uppercase animate-pulse">
              <span>🔥 UPDATES: Aadhaar mobile mapping forms active at shop Karala.</span>
              <span>⚡ PAN cards processed with instant biometric verification.</span>
              <span>🚆 IRCTC Authorized rail reservations open for tatkaal requests.</span>
              <span>🎫 Passport slots now available with instant documentation pre-screening.</span>
            </div>
          </div>

          {/* HERO BANNER SECTION */}
          <section id="hero_section" className="relative pt-12 pb-20 md:pt-20 md:pb-32 px-4 px-6 max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center text-left">
            <div className="lg:col-span-7 space-y-6">
              
              <div className="inline-flex items-center gap-2 bg-gradient-to-r from-emerald-500/15 to-green-500/15 border border-emerald-500/20 px-3 py-1.5 rounded-full text-xs font-bold font-mono text-emerald-600 dark:text-emerald-400">
                <Sparkles className="w-3.5 h-3.5 animate-spin" /> DELH&apos;S CHOSEN ONLINE SERVICE JUNCTION
              </div>

              <h2 className="text-3xl md:text-5xl lg:text-6xl font-extrabold font-display leading-tight tracking-tight dark:text-white">
                Premium Cyber Cafe & <br className="hidden md:inline" />
                <span className="bg-gradient-to-r from-emerald-600 via-green-600 to-emerald-700 bg-clip-text text-transparent">Digital Solution</span> Center
              </h2>

              <p className="text-sm md:text-base text-slate-600 dark:text-slate-400 max-w-xl leading-relaxed">
                Welcome to <strong className="text-slate-800 dark:text-slate-100 font-bold">Rupansh Online Solution</strong>. We process PAN Card registrations, Aadhaar linkages, EPIC Voter ID enrollments, Normal/Tatkaal Passport filings, IRCTC Railway Ticket reservations, and professional forms submissions with total safety, speed, and real-time step tracking.
              </p>

              {/* Action grid links */}
              <div className="flex flex-col sm:flex-row gap-4 pt-2">
                <button
                  onClick={() => {
                    setIsRegistering(true);
                    setLoginModalOpen(true);
                  }}
                  className="bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-extrabold text-sm py-3.5 px-8 rounded-2xl shadow-xl shadow-orange-500/20 hover:-translate-y-0.5 active:translate-y-0 transition-all cursor-pointer flex items-center justify-center gap-2"
                >
                  Get Documents Screened <ArrowRight className="w-4 h-4" />
                </button>

                <a
                  href="#services_section"
                  className="border border-emerald-200 dark:border-emerald-800 bg-white/50 dark:bg-emerald-900/40 hover:bg-emerald-50 dark:hover:bg-emerald-950/30 text-emerald-700 dark:text-emerald-300 font-extrabold text-sm py-3.5 px-8 rounded-2xl transition flex items-center justify-center gap-2"
                >
                  Explore 11 core services
                </a>
              </div>

              {/* Hero Statistics */}
              <div className="pt-8 grid grid-cols-2 md:grid-cols-3 gap-6 border-t border-slate-200 dark:border-slate-850">
                <div>
                  <p className="text-2xl md:text-3xl font-black font-display text-emerald-600 dark:text-emerald-400">5,000+</p>
                  <p className="text-[10px] text-slate-400 font-mono uppercase tracking-wider mt-0.5">Forms Handled</p>
                </div>
                <div>
                  <p className="text-2xl md:text-3xl font-black font-display text-emerald-600 dark:text-emerald-400">99.8%</p>
                  <p className="text-[10px] text-slate-400 font-mono uppercase tracking-wider mt-0.5">Success Audit Rate</p>
                </div>
                <div className="col-span-2 md:col-span-1">
                  <p className="text-2xl md:text-3xl font-black font-display text-emerald-600 dark:text-emerald-400">Under 5m</p>
                  <p className="text-[10px] text-slate-400 font-mono uppercase tracking-wider mt-0.5">Response Time</p>
                </div>
              </div>

            </div>

            {/* Right Side visual internet cafe graphics mock */}
            <div className="lg:col-span-5 relative w-full flex justify-center animate-float">
              
              {/* Complex Glassmorphism Stack simulating real documents portal */}
              <div className="w-full max-w-sm rounded-3xl bg-white dark:bg-slate-900/60 p-6 shadow-2xl border border-slate-200 dark:border-slate-800 relative z-10 glass-panel animate-float">
                
                {/* Header visual */}
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1.5">
                    <span className="w-3 h-3 rounded-full bg-red-500"></span>
                    <span className="w-3 h-3 rounded-full bg-yellow-500"></span>
                    <span className="w-3 h-3 rounded-full bg-green-500"></span>
                  </div>
                  <span className="text-[10px] font-sans font-semibold text-slate-500 bg-slate-100 dark:bg-slate-800/80 px-2 py-1 rounded">Safe & Secure Portal</span>
                </div>

                <div className="space-y-4 text-left">
                  
                  {/* Item 1 */}
                  <div className="p-3 bg-emerald-500/5 rounded-xl border border-emerald-500/10 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white text-xs font-bold font-display">PAN</div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold dark:text-white truncate">PAN Identification Form</p>
                      <p className="text-[9px] text-slate-400 uppercase font-sans mt-0.5">Completed • Ready for pickup</p>
                    </div>
                    <span className="text-xs font-bold text-orange-500">✓ Sent</span>
                  </div>

                  {/* Item 2 */}
                  <div className="p-3 bg-emerald-500/5 rounded-xl border border-emerald-500/10 flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white text-xs font-bold font-display">UID</div>
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-bold dark:text-white truncate">Aadhaar Address update tracker</p>
                      <p className="text-[9px] text-slate-400 uppercase font-sans mt-0.5">Submitted • Under verification</p>
                    </div>
                    <span className="text-xs font-bold text-orange-500">⚡ Active</span>
                  </div>

                  {/* Latest Services Updates */}
                  <div className="bg-slate-50 dark:bg-slate-950 p-4 rounded-2xl border border-slate-200 dark:border-slate-850 space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 uppercase tracking-wider">Latest Portal Updates</span>
                      <span className="text-[10px] font-semibold text-orange-500 bg-orange-500/10 px-2 py-0.5 rounded-full">Open</span>
                    </div>

                    <div className="space-y-2 text-[11px] text-slate-600 dark:text-slate-350 text-left">
                      <div className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                        <p>All client documents are handled with strict privacy.</p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                        <p>Direct tracking on your phone via SMS/WhatsApp.</p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                        <p>Friendly assistance for form filings in Delhi.</p>
                      </div>
                      <div className="flex items-center gap-1.5">
                        <span className="w-1.5 h-1.5 rounded-full bg-orange-550 animate-ping"></span>
                        <p className="font-bold text-orange-600 dark:text-orange-400">Rupansh Online Services are fully active!</p>
                      </div>
                    </div>
                  </div>

                </div>

              </div>

              {/* Glowing decorative badges */}
              <div className="absolute -top-6 -left-6 bg-gradient-to-r from-emerald-600 to-green-500 text-white font-bold text-xs p-4 rounded-2xl shadow-lg z-20 hidden md:flex items-center gap-2">
                <Award className="w-4 h-4 text-orange-400" /> 100% Secure Uploads
              </div>

              <div className="absolute -bottom-6 -right-6 bg-slate-900 border border-slate-850 text-slate-200 text-xs p-4 rounded-2xl shadow-xl z-20 hidden md:block">
                <span className="block font-sans font-bold text-[10px] text-slate-500 uppercase">Delhi - Karala Center</span>
                <span className="block mt-0.5 font-extrabold text-orange-500">Shop No. 14/15</span>
              </div>

            </div>
          </section>

          {/* SERVICES GRID SECTION */}
          <section id="services_section" className="bg-slate-100 dark:bg-slate-900/40 py-20 px-4 transition-colors">
            <div className="max-w-7xl mx-auto space-y-12">
              
              <div className="text-center max-w-xl mx-auto space-y-3">
                <span className="text-xs font-black uppercase font-mono tracking-widest text-emerald-600 dark:text-emerald-450">DIGITAL DEPARTMENTS REGISTER</span>
                <h3 className="text-2xl md:text-4xl font-extrabold font-display dark:text-white">Our Cyber & Online E-Services</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm">
                  Click on any service card below to view detailed guides, required legal documents checklists, processing timelines, and price estimates.
                </p>
              </div>

              {/* Services cards matrix */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
                {servicesList.map((item) => (
                  <div 
                    key={item.id}
                    onClick={() => setActiveDetailService(item)}
                    className="cursor-pointer bg-white dark:bg-slate-900 rounded-3xl p-6 text-left border border-slate-200 dark:border-slate-800 hover:-translate-y-1.5 transition-all duration-300 shadow-sm hover:shadow-xl group relative overflow-hidden"
                  >
                    
                    {/* Glowing Accent gradient at top card border */}
                    <div className="absolute top-0 inset-x-0 h-[3px] bg-gradient-to-r from-emerald-600 to-green-500"></div>

                    <div className="w-12 h-12 rounded-2xl bg-neutral-50 dark:bg-slate-850 flex items-center justify-center mb-5 group-hover:scale-110 transition-transform">
                      {/* Generates placeholder index bullet icons */}
                      <span className="text-base font-extrabold bg-gradient-to-r from-emerald-600 to-emerald-800 bg-clip-text text-transparent font-display">
                        {item.title.substring(0,2).toUpperCase()}
                      </span>
                    </div>

                    <h4 className="text-lg font-bold text-slate-800 dark:text-slate-100 group-hover:text-orange-500 transition-colors font-display">
                      {item.title}
                    </h4>

                    <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 line-clamp-3 leading-relaxed">
                      {item.description}
                    </p>

                    <div className="mt-5 pt-4 border-t border-slate-100 dark:border-slate-850 flex items-center justify-between text-[11px] font-mono">
                      <span className="text-slate-400">TIME: {item.completionTime}</span>
                      <span className="text-orange-550 dark:text-orange-400 font-extrabold flex items-center gap-0.5">
                        Details <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>

                  </div>
                ))}
              </div>

            </div>
          </section>

          {/* EXTENSIVE ADVANTAGES "WHY CHOOSE US" */}
          <section id="why_choose_us" className="py-20 px-4 max-w-7xl mx-auto space-y-16">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center text-left">
              
              <div className="lg:col-span-5 space-y-6">
                <span className="text-xs font-black uppercase font-mono tracking-widest text-emerald-600 dark:text-emerald-400">UTILITY PROMISES</span>
                <h3 className="text-2xl md:text-4xl font-extrabold font-display dark:text-white">Why Delhi Chooses Rupansh Online Solution</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed">
                  Unlike traditional offline-only cyber cafes where you waste hours sitting around, we operate a dual desktop dashboard platform. Upload your details directly, register securely, pay via QR scans, and chat instantly with our legal administrators.
                </p>

                <div className="space-y-4">
                  
                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-450 flex items-center justify-center flex-shrink-0">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold dark:text-white text-sm">Direct Official Processing</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">We check and process application updates directly on official government portals for stable and certified voter, PAN, and Aadhaar links.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-650 dark:text-emerald-400 flex items-center justify-center flex-shrink-0">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold dark:text-white text-sm">Instant Processing Alerts</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Get timely WhatsApp updates directly to your mobile number <span className="font-bold">8130670350</span> or clear email receipts instantly.</p>
                    </div>
                  </div>

                  <div className="flex gap-4">
                    <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-450 flex items-center justify-center flex-shrink-0">
                      <CheckCircle2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold dark:text-white text-sm">Safe & Highly Confidential</h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">Your physical folders, digital logs, and contact details are kept fully private. We never share your credentials or files under any circumstances.</p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Testimonials slider view as part of Advantages */}
              <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl p-6 md:p-10 space-y-6 relative overflow-hidden text-left glass-panel">
                
                <p className="text-xs font-bold font-mono text-emerald-600 dark:text-emerald-400 uppercase flex items-center gap-1.5">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full animate-ping"></span> Real Testimonials from Karala locals
                </p>

                <div className="relative min-h-[140px] flex items-center font-display">
                  
                  {/* Testimonial Active Slider Box */}
                  <div className="animate-fade-in space-y-4">
                    <p className="text-sm md:text-base italic dark:text-slate-200 leading-relaxed font-medium">
                      &quot;{testimonials[testimonialIndex].feedback}&quot;
                    </p>
                    <div>
                      <h4 className="font-extrabold text-sm dark:text-white">
                        {testimonials[testimonialIndex].name}
                      </h4>
                      <p className="text-xs text-slate-500 font-mono mt-0.5 uppercase tracking-wider">
                        {testimonials[testimonialIndex].role}
                      </p>
                    </div>
                  </div>

                </div>

                {/* Slider nav controllers */}
                <div className="flex justify-between items-center pt-4 border-t border-slate-100 dark:border-slate-850">
                  <div className="flex items-center gap-1.5">
                    {testimonials.map((_, indx) => (
                      <span 
                        key={indx} 
                        className={`w-2 h-2 rounded-full transition-all ${testimonialIndex === indx ? 'w-5 bg-orange-500' : 'bg-slate-300 dark:bg-slate-700'}`}
                      ></span>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <button 
                      onClick={handlePrevTestimonial}
                      className="p-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
                      aria-label="Previous review"
                    >
                      🡐
                    </button>
                    <button 
                      onClick={handleNextTestimonial}
                      className="p-2 border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-xl transition cursor-pointer"
                      aria-label="Next review"
                    >
                      🡒
                    </button>
                  </div>
                </div>

              </div>

            </div>
          </section>

          {/* ACCORDION FAQS SECTION */}
          <section id="faq_section" className="bg-slate-100 dark:bg-slate-900/40 py-20 px-4 transition-colors">
            <div className="max-w-4xl mx-auto space-y-12 text-left">
              
              <div className="text-center space-y-3 max-w-xl mx-auto">
                <span className="text-xs font-black tracking-widest font-mono text-emerald-600 dark:text-emerald-450 uppercase">HELP DESK ASSISTANCE</span>
                <h3 className="text-2xl md:text-4xl font-extrabold font-display dark:text-white">Frequently Asked Questions</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm">
                  Got queries regarding standard processing fees, file criteria thresholds, or shop guidelines? Look at answers generated by operators directly.
                </p>
              </div>

              {/* Accordion list */}
              <div className="space-y-4">
                {faqs.map((faq, index) => {
                  const isOpen = activeFaq === index;
                  return (
                    <div 
                      key={index}
                      className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 overflow-hidden shadow-sm animate-fade-in"
                    >
                      <button
                        onClick={() => setActiveFaq(isOpen ? null : index)}
                        className="w-full text-left p-5 flex items-center justify-between font-bold text-sm md:text-base dark:text-slate-200 focus:outline-none hover:bg-slate-50 dark:hover:bg-slate-850 transition"
                      >
                        <span className="font-display font-bold leading-tight">{faq.q}</span>
                        <ChevronDown className={`w-5 h-5 text-slate-500 transition-transform ${isOpen ? 'rotate-180 text-orange-500' : ''}`} />
                      </button>

                      {isOpen && (
                        <div className="px-5 pb-5 pt-1 text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed border-t border-slate-100 dark:border-slate-850 animate-fade-in font-sans">
                          {faq.a}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

            </div>
          </section>

          {/* LOCATION, GET IN TOUCH AND CONTACT SECTION */}
          <section id="contact_section" className="py-20 px-4 max-w-7xl mx-auto space-y-12 text-left relative">
            
            <div className="text-center space-y-3 max-w-xl mx-auto">
              <span className="text-xs font-black tracking-widest font-mono text-emerald-600 dark:text-emerald-400 uppercase">LOCATION MAP & INBOX</span>
              <h3 className="text-2xl md:text-4xl font-extrabold font-display dark:text-white">Contact Us / Visit Shop</h3>
              <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm">
                Get directions to Anandpur Dham Karala, write us a direct mail, or click call/messaging triggers below for immediate solutions.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 md:gap-12 items-stretch">
              
              {/* Left Column Contacts Info & Maps */}
              <div className="lg:col-span-6 space-y-6 flex flex-col justify-between">
                
                <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-3xl space-y-4 shadow-sm flex-1">
                  
                  <h4 className="font-extrabold text-base md:text-lg dark:text-white font-display uppercase tracking-tight">Rupansh Online Solution Details</h4>
                  
                  <div className="space-y-3.5 text-xs sm:text-sm">
                    
                    <p className="flex items-start gap-3.5 text-slate-600 dark:text-slate-300">
                      <MapPin className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0 mt-0.5" />
                      <span>
                        <strong>Address:</strong> Shop No. 14/15, Anandpur Dham, Karala, North West Delhi, Delhi - 110081(Karala bus stand sector road)
                      </span>
                    </p>

                    <p className="flex items-center gap-3.5 text-slate-600 dark:text-slate-300">
                      <Phone className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                      <span><strong>Phone:</strong> <a href="tel:8130670350" className="text-emerald-600 dark:text-emerald-400 font-bold hover:underline">8130670350</a></span>
                    </p>

                    <p className="flex items-center gap-3.5 text-slate-600 dark:text-slate-300">
                      <Mail className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                      <span><strong>Email:</strong> <span className="font-mono text-emerald-600 dark:text-emerald-400">rupanshonlinesolutions@gmail.com</span></span>
                    </p>

                    <p className="flex items-center gap-3.5 text-slate-600 dark:text-slate-300">
                      <Clock className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                      <span><strong>Store Timings:</strong> 09:00 AM - 08:00 PM (Monday to Saturday)</span>
                    </p>

                  </div>

                  {/* Hot Interactive quick trigger CTA links */}
                  <div className="pt-4 grid grid-cols-2 gap-3">
                    <a 
                      href="tel:8130670350"
                      className="bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs py-2.5 rounded-xl text-center shadow flex items-center justify-center gap-1 cursor-pointer transition-all"
                    >
                      📞 Call Operator Now
                    </a>
                    
                    <a 
                      href="https://wa.me/918130670350"
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-emerald-650 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 rounded-xl text-center shadow flex items-center justify-center gap-1 cursor-pointer transition-all border border-emerald-500/20"
                    >
                      💬 WhatsApp Message
                    </a>
                  </div>

                </div>

                {/* Google Map Embedded iframe for Anandpur Dham, Karala */}
                <div className="rounded-3xl overflow-hidden h-64 border border-slate-200 dark:border-slate-800 shadow-sm relative">
                  <iframe 
                    title="Rupansh Online Solution Karala Delhi Map"
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3497.5255395786567!2d77.0195657!3d28.7337965!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390da292c5555555%3A0xe545c11bc3298c5!2sKarala%2C%20Delhi%20110081!5e0!3m2!1sen!2sin!4v1680000000000" 
                    width="100%" 
                    height="100%" 
                    style={{ border: 0 }} 
                    allowFullScreen 
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                  ></iframe>
                </div>

              </div>

              {/* Right Column Custom Contact Inbox form */}
              <div className="lg:col-span-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 md:p-8 rounded-3xl shadow-sm text-left">
                
                <h4 className="font-extrabold text-base md:text-lg dark:text-white font-display uppercase tracking-tight mb-2">Send Direct message to Shop inbox</h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 mb-6 font-sans">
                  Have quick queries or requirements concerning legal filings and pricing lists? Write your details down and a representative will get back to you.
                </p>

                {contactSuccess && (
                  <div className="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-650 dark:text-emerald-400 rounded-xl flex items-center gap-2 animate-fade-in text-xs font-semibold">
                    <CheckCircle2 className="w-4 h-4" /> Message dispatched successfully! Operators will respond to your mobile shortly.
                  </div>
                )}

                <form onSubmit={handleContactSubmit} className="space-y-4">
                  
                  <div>
                    <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                      Candidate Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={contactName}
                      onChange={(e) => setContactName(e.target.value)}
                      placeholder="Candidate full name"
                      className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                      Active Phone Number *
                    </label>
                    <input
                      type="tel"
                      required
                      value={contactPhone}
                      onChange={(e) => setContactPhone(e.target.value)}
                      placeholder="10 digit phone contact number"
                      className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                      Query Subject
                    </label>
                    <input
                      type="text"
                      value={contactSubject}
                      onChange={(e) => setContactSubject(e.target.value)}
                      placeholder="e.g. Passport slot booking inquiry"
                      className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold font-mono tracking-wider dark:text-slate-300 mb-1.5 uppercase">
                      Brief Message Description *
                    </label>
                    <textarea
                      required
                      rows={3}
                      value={contactMessage}
                      onChange={(e) => setContactMessage(e.target.value)}
                      placeholder="Explain your queries or service expectations"
                      className="w-full bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-sm px-4 py-2.5 focus:outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-extrabold text-sm py-3.5 rounded-xl shadow-md shadow-orange-500/10 transition-all cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    Send message to operator
                  </button>

                </form>

              </div>

            </div>

          </section>

          {/* FINAL CTA JUMBOTRON */}
          <section className="bg-gradient-to-tr from-emerald-950 via-emerald-900 to-green-950 py-16 px-4 text-center text-white border-t border-emerald-900">
            <div className="max-w-4xl mx-auto space-y-6">
              <h3 className="text-2xl md:text-4xl font-black font-display tracking-tight leading-tight text-white">Ready to verify and process your government registrations?</h3>
              <p className="text-emerald-100 text-xs sm:text-sm max-w-xl mx-auto leading-relaxed">
                Connect with our state-recognized Delhi validation hub now. High-speed scans, IRCTC railway ticket files, biometric PAN cards, and more are processed under strict privacy guidelines.
              </p>
              
              <div className="flex flex-col sm:flex-row justify-center items-center gap-4 pt-2">
                <button
                  onClick={() => {
                    setIsRegistering(true);
                    setLoginModalOpen(true);
                  }}
                  className="bg-orange-500 hover:bg-orange-600 text-white font-extrabold text-sm py-3 px-8 rounded-xl shadow-lg shadow-orange-500/20 hover:-translate-y-0.5 active:translate-y-0 transition cursor-pointer"
                >
                  Register Application Account Now
                </button>
                <a
                  href="tel:8130670350"
                  className="bg-emerald-800/60 border border-emerald-700 hover:bg-emerald-800 text-white font-semibold text-sm py-3 px-8 rounded-xl transition flex items-center gap-1.5"
                >
                  Call operator: 8130670350
                </a>
              </div>
            </div>
          </section>

          {/* SITE FOOTER */}
          <footer className="bg-slate-950 text-slate-450 py-12 px-4 border-t border-slate-900 text-left">
            <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 pb-8 border-b border-slate-900">
              
              <div className="md:col-span-5 space-y-4">
                <div className="flex items-center gap-2">
                  <span className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-black text-xs">R</span>
                  <span className="font-extrabold text-sm text-slate-200 tracking-wider">RUPANSH ONLINE SOLUTION</span>
                </div>
                <p className="text-xs text-slate-500 leading-relaxed max-w-sm">
                  Government registered E-Service Point and digital internet cafe processing PAN, Aadhaar linking, Voter applications, IRCTC booking, other digital assistance programs and professional forms filling under proper state compliance rules.
                </p>
              </div>

              <div className="md:col-span-3 space-y-3.5 text-xs">
                <h4 className="font-bold text-slate-250 uppercase tracking-widest font-mono text-[10px]">E-Gov Services</h4>
                <ul className="space-y-2">
                  <li><a href="#services_section" className="hover:text-orange-500 font-medium">PAN Card Updates</a></li>
                  <li><a href="#services_section" className="hover:text-orange-500 font-medium">Aadhaar Validation Help</a></li>
                  <li><a href="#services_section" className="hover:text-orange-500 font-medium">Voter ID EPIC Enlistments</a></li>
                  <li><a href="#services_section" className="hover:text-orange-500 font-medium">Tatkaal IRCTC Travel Tickets</a></li>
                </ul>
              </div>

              <div className="md:col-span-4 space-y-3.5 text-xs">
                <h4 className="font-bold text-slate-200 uppercase tracking-widest font-mono text-[10px]">Administrative Legal Disclaimer</h4>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Rupansh Online Solution is an independent, non-governmental private online processing facilitator cafe. Standard charges involve online service charges in compliance with authorized operational guidelines. All digital data is heavily encrypted using secured standards.
                </p>
              </div>

            </div>

            <div className="max-w-7xl mx-auto pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500 font-mono">
              <p>© 2026 Rupansh Online Solution. Delhi - 110081. All Rights Reserved.</p>
              <div className="flex items-center gap-4">
                <a 
                  onClick={() => {
                    // Quick admin trigger backdoor shortcut
                    setLoginMobile('8287738592');
                    setLoginPassword('2009');
                    setIsRegistering(false);
                    setLoginModalOpen(true);
                  }}
                  className="hover:underline text-slate-600 hover:text-cyan-400 cursor-pointer"
                >
                  Admin Portal Bypass
                </a>
                <span>•</span>
                <span>ISO 9001-2015 Cyber Point</span>
              </div>
            </div>
          </footer>

        </div>
      )}

      {/* RETAIN FULL COMPLIANCE: MODAL 1: AUTHENTICATION REGISTER/LOGIN (JWT, bcrypt secure form) */}
      {loginModalOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-md w-full p-6 md:p-8 relative text-left shadow-2xl animate-scale-up">
            
            <button
              onClick={() => {
                setLoginModalOpen(false);
                setModalError('');
              }}
              className="absolute top-5 right-5 p-1 rounded-full text-slate-400 hover:text-red-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              aria-label="Close modal form"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-xl font-bold font-display dark:text-white flex items-center gap-1.5 uppercase tracking-tight">
              {isRegistering ? 'Create Account' : 'Sign In To Your Account'}
            </h3>
            <p className="text-xs text-slate-400 mt-1 font-sans">
              {isRegistering ? 'Register to manage all your digital e-services' : 'Login to view document statuses and chat with us'}
            </p>

            {modalError && (
              <div className="mt-4 p-3 bg-rose-500/15 text-rose-500 text-xs rounded-xl font-semibold border border-rose-500/10">
                ⚠️ {modalError}
              </div>
            )}

            <form onSubmit={handleAuthSubmit} className="space-y-4 mt-6">
              {isRegistering && (
                <div>
                  <label className="block text-[10px] font-semibold font-mono uppercase tracking-wider dark:text-slate-400 mb-1">
                    Candidate Legal Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    placeholder="Enter candidate legal name"
                    className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white font-sans"
                  />
                </div>
              )}

              <div>
                <label className="block text-[10px] font-semibold font-mono uppercase tracking-wider dark:text-slate-400 mb-1">
                  Candidate Mobile / Phone *
                </label>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={loginMobile}
                  onChange={(e) => setLoginMobile(e.target.value)}
                  placeholder="10 digit phone number"
                  className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white font-sans"
                />
              </div>

              {isRegistering && (
                <div>
                  <label className="block text-[10px] font-semibold font-mono uppercase tracking-wider dark:text-slate-400 mb-1">
                    Candidate Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    placeholder="candidate@gmail.com"
                    className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white font-sans"
                  />
                </div>
              )}

              <div>
                <label className="block text-[10px] font-semibold font-mono uppercase tracking-wider dark:text-slate-400 mb-1">
                  Access Password *
                </label>
                <input
                  type="password"
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="Password keys"
                  className="w-full bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700/80 rounded-xl text-sm px-4 py-2.5 outline-none focus:ring-1 focus:ring-orange-500 focus:border-orange-500 dark:text-white font-sans"
                />
              </div>

              <button
                type="submit"
                disabled={authLoading}
                className="w-full bg-gradient-to-r from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700 text-white font-extrabold text-sm py-3 rounded-xl transition shadow-lg shadow-orange-500/10 flex items-center justify-center gap-1.5 cursor-pointer font-sans"
              >
                {authLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Transmitting credentials...
                  </>
                ) : (
                  isRegistering ? 'Register & Connect Securely' : 'Sign In Securely'
                )}
              </button>

              <div className="pt-2 text-center">
                <button
                  type="button"
                  onClick={() => {
                    setIsRegistering(!isRegistering);
                    setModalError('');
                  }}
                  className="text-xs text-orange-500 hover:text-orange-600 hover:underline font-bold font-sans"
                >
                  {isRegistering 
                    ? 'Already have an account? Sign In here' 
                    : 'Need an account? Register here'}
                </button>
              </div>

            </form>
          </div>
        </div>
      )}

      {/* RETAIN FULL COMPLIANCE MODE: MODAL 2: DETAILED EXPANDED SERVICE ACCORDION GUIDES */}
      {activeDetailService && (
        <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-3xl max-w-lg w-full p-6 md:p-8 relative text-left shadow-2xl animate-scale-up">
            
            <button
              onClick={() => setActiveDetailService(null)}
              className="absolute top-5 right-5 p-1 rounded-full text-slate-400 hover:text-red-500 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              aria-label="Close details"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-[9px] font-mono uppercase bg-slate-100 dark:bg-slate-800 px-2.5 py-1 rounded text-slate-400">
              Service Guide Card
            </span>

            <h3 className="text-xl font-extrabold font-display dark:text-white mt-3 flex items-center gap-2">
              {activeDetailService.title}
            </h3>

            <p className="text-xs text-slate-500 dark:text-slate-400 mt-2.5 leading-relaxed font-sans">
              {activeDetailService.description}
            </p>

            <div className="mt-5 space-y-4">
              
              <div>
                <h4 className="text-xs font-bold font-mono text-indigo-600 dark:text-cyan-400 uppercase tracking-wider mb-2">
                  📋 REQUIRED ORIGINAL DOCUMENTS:
                </h4>
                <ul className="space-y-1.5">
                  {activeDetailService.requiredDocuments.map((doc, docIdx) => (
                    <li key={docIdx} className="text-xs text-slate-600 dark:text-slate-300 flex items-start gap-2">
                      <span className="text-emerald-500 text-xs">✓</span> <span>{doc}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-2 grid grid-cols-2 gap-4 border-t border-slate-100 dark:border-slate-850 text-xs text-slate-600 dark:text-slate-400 font-mono">
                <div>
                  <span>ESTIMATE CHARGE:</span>
                  <p className="font-bold text-slate-800 dark:text-white mt-0.5">{activeDetailService.priceEstimate}</p>
                </div>
                <div>
                  <span>PROCESSING TIME:</span>
                  <p className="font-bold text-slate-800 dark:text-white mt-0.5">{activeDetailService.completionTime}</p>
                </div>
              </div>

            </div>

            <div className="mt-8 flex gap-3">
              <button
                onClick={() => {
                  setActiveDetailService(null);
                  setIsRegistering(true);
                  setLoginModalOpen(true);
                }}
                className="flex-1 bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-700 hover:to-indigo-700 text-white font-extrabold text-xs py-3 rounded-xl shadow-md transition-all cursor-pointer text-center"
              >
                Apply On Portal
              </button>
              <button
                onClick={() => setActiveDetailService(null)}
                className="px-6 border border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-850 font-bold text-xs rounded-xl transition"
              >
                Close
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
